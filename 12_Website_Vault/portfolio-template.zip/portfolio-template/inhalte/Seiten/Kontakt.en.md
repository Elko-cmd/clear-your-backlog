---
title: Contact
---

For enquiries about exhibitions, performances and loans:

**Email:** alex@example.org
**Instagram:** [@alex.beispiel](https://instagram.com/)

Studio: Musterstraße 1, 34117 Kassel (by appointment)

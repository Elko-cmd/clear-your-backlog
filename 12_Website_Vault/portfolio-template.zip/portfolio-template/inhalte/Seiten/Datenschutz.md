---
titel: Datenschutz
---

> [!warning] Platzhalter
> Dieser Text ist nur ein Beispiel und **keine Rechtsberatung**. Bitte an die eigene Website anpassen, z.B. mit einem Datenschutz-Generator, und im Zweifel prüfen lassen.

## Hosting
Diese Website wird über GitHub Pages (GitHub Inc., USA) bereitgestellt. Beim Aufruf werden technisch notwendige Daten (z.B. IP-Adresse) von GitHub verarbeitet.

## Eingebettete Inhalte
Videos und Audio von Drittanbietern (z.B. YouTube, Vimeo, Bandcamp) werden erst geladen, wenn du auf „Abspielen“ klickst. Erst dann werden Daten an den jeweiligen Anbieter übertragen.

## Keine Cookies
Diese Website setzt keine Cookies. Wenn du „immer laden“ auswählst, wird diese Entscheidung nur lokal in deinem Browser gespeichert.

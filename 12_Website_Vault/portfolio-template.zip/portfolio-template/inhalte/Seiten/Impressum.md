---
titel: Impressum
---

> [!warning] Platzhalter
> Dieser Text ist nur ein Beispiel und **keine Rechtsberatung**. Ein Impressum ist in Deutschland für die meisten Websites Pflicht. Bitte mit eigenen Angaben ersetzen und im Zweifel prüfen lassen.

Angaben gemäß § 5 DDG:

Alex Beispiel
Musterstraße 1
34117 Kassel

E-Mail: alex@example.org

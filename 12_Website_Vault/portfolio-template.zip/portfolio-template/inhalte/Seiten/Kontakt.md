---
titel: Kontakt
---

Für Anfragen zu Ausstellungen, Aufführungen und Leihgaben:

**E-Mail:** alex@example.org
**Instagram:** [@alex.beispiel](https://instagram.com/)

Studio: Musterstraße 1, 34117 Kassel (nach Vereinbarung)

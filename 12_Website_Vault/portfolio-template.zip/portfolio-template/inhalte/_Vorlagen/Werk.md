---
titel: 
jahr: 
art: 
material: 
masse: 
dauer: 
orte:
  - 
titelbild: 
reihenfolge: 
veroeffentlichen: true
---

Kurze Beschreibung des Werks.

![[bild.jpg|Bildunterschrift. Foto: Name]]

## Credits

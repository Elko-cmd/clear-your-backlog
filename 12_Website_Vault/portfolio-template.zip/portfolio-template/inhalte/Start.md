Alex Beispiel arbeitet mit Klang, Raum und Situationen. Die Arbeiten entstehen oft vor Ort – als Installationen, Aufnahmen oder Handlungsanweisungen für ein Publikum.

Aktuell: [[Resonanzraum]] ist bis März im Kunstverein Musterstadt zu sehen.

![[portrait.jpg|Alex Beispiel im Atelier, 2026]]

---
vorlage: galerie
---

Diese Notiz steuert das **Aussehen** der Website (oben, in den Eigenschaften). Der Text hier erscheint nirgends.

Am einfachsten geht es in der Vorschau: unten auf **„Aa Gestaltung“** klicken, ausprobieren, speichern. Die Werte landen dann hier.

## Vorlagen
`weiss` · `galerie` · `editorial` · `brutal` · `nacht` · `signal` · `studio`

Jede Eigenschaft, die du hier zusätzlich einträgst, überschreibt die Vorlage. Beispiel:

```yaml
vorlage: editorial
farben:
  akzent: "#e4002b"
schrift_titel: syne
titelgroesse: riesig
```

Alle Möglichkeiten stehen in [[LIESMICH#Gestaltung]].

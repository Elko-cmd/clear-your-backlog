# LIESMICH – So schreibst du deine Website

*Diese Notiz erscheint nicht auf der Website. English: [[README (English)]]*

Alles in diesem Vault wird zur Website – außer Notizen direkt hier in der obersten Ebene (wie diese) und Ordnern oder Dateien, die mit `_` beginnen.

Läuft die Vorschau (Doppelklick auf `Start (Mac).command` bzw. `Start (Windows).bat`), siehst du jede gespeicherte Änderung sofort im Browser.

---

## Die Ordner

| Ort | Wird zu |
|---|---|
| `Einstellungen` | Name, Navigation, Sprachen der ganzen Website |
| `Gestaltung` | Farben, Schriften, Aufbau – siehe unten |
| `Start` | Startseite |
| `CV` | Lebenslauf unter /cv |
| `Werke/…` | Je Notiz eine Werkseite, alle zusammen auf der Übersicht /werke |
| `Seiten/…` | Weitere Seiten wie Kontakt, Impressum |
| `_Vorlagen/` | Vorlagen für neue Notizen (nicht auf der Website) |

---

## Ein neues Werk anlegen

1. Im Ordner `Werke` einen neuen Ordner mit dem Namen des Werks anlegen.
2. Darin eine neue Notiz mit demselben Namen anlegen.
3. Befehl **„Vorlage einfügen“** (Strg/Cmd + P → „Vorlage“) und `Werk` wählen.
4. Eigenschaften ausfüllen, Text schreiben, Bilder hineinziehen. Sie landen automatisch im Unterordner `media`.

### Eigenschaften eines Werks

| Eigenschaft | Bedeutung | Beispiel |
|---|---|---|
| `titel` | Titel (sonst der Dateiname) | `Resonanzraum` |
| `jahr` | Jahr | `2026` |
| `art` | Gattung, Medium | `Klanginstallation` |
| `material` | Material, Technik | `8 Lautsprecher, Stahl` |
| `masse` | Maße | `200 × 120 cm` |
| `dauer` | Dauer | `12 min` |
| `orte` | Liste: wo gezeigt | `- Kunstverein, 2026` |
| `angaben` | Eigene Zeilen: Bezeichnung und Wert | `Auflage: 3 + 1 AP` |
| `titelbild` | Bild für die Übersicht (sonst das erste Bild) | `"[[foto.jpg]]"` |
| `beschreibung` | Kurztext für Suchmaschinen und Link-Vorschauen | |
| `reihenfolge` | Position auf der Übersicht (1 = zuerst) | `1` |
| `slug` | Eigene Adresse statt der automatischen | `feldaufnahmen` |
| `veroeffentlichen` | `false` = noch nicht zeigen | `false` |

Ohne `reihenfolge` werden Werke nach Jahr sortiert, das neueste zuerst.

---

## Text

Normales Markdown funktioniert: `**fett**`, `*kursiv*`, Listen, Links, Tabellen, `==markiert==`.

- `## Überschrift` oder eine Trennlinie `---` beginnt einen **neuen Block**, den du im Layout einzeln platzieren kannst.
- `[[Andere Notiz]]` verlinkt auf ein Werk oder eine Seite. Ist das Ziel nicht öffentlich, bleibt nur der Text stehen.
- `%% privat %%` – alles zwischen den `%%` erscheint **nicht** auf der Website.
- `^name` am Ende eines Absatzes gibt dem Textblock eine feste Kennung. Dann bleibt das Layout auch erhalten, wenn du davor neue Abschnitte einfügst.

---

## Bilder

```
![[foto.jpg]]
![[foto.jpg|Bildunterschrift. Foto: Name]]
```

Mehrere Bilder **direkt untereinander, ohne Leerzeile** → **Galerie** (Klick öffnet die Großansicht):

```
![[detail-1.jpg]]
![[detail-2.jpg]]
![[detail-3.jpg]]
```

Oder als Galerie mit gemeinsamer Unterschrift:

```
> [!gallery] Aufbau, März 2026
> ![[aufbau-1.jpg]]
> ![[aufbau-2.jpg]]
```

Erlaubt: JPG, PNG, WebP, AVIF, TIFF, GIF, SVG. iPhone-Fotos (HEIC) bitte vorher als JPG exportieren. Große Bilder sind kein Problem: Die Website erzeugt automatisch kleinere Versionen.

---

## Audio, Video, PDF

```
![[aufnahme.mp3|Auszug, 3 min]]
![[ausschnitt.mp4|Videoausschnitt]]
![[katalog.pdf|Katalog (PDF)]]
```

Audio: MP3, WAV, OGG, M4A, FLAC. Video: am besten MP4 (H.264). **Lange Videos besser auf Vimeo oder YouTube hochladen** und den Link einfügen. GitHub nimmt keine Dateien über 100 MB an.

---

## YouTube, Vimeo, Bandcamp & Co.

Den Link **allein in eine Zeile** schreiben:

```
https://www.youtube.com/watch?v=…
https://vimeo.com/123456789
https://soundcloud.com/name/titel
https://open.spotify.com/album/…
https://www.mixcloud.com/name/sendung/
https://archive.org/details/…
https://name.bandcamp.com/album/titel
```

Mit Bildunterschrift:

```
> [!embed] Live-Mitschnitt, Kassel 2025
> https://vimeo.com/123456789
```

**Bandcamp:** Falls der normale Link nicht funktioniert, in Bandcamp auf **Teilen/Einbetten** klicken, den Code kopieren und so einfügen:

```
> [!embed] Album
> <iframe src="https://bandcamp.com/EmbeddedPlayer/album=123456/…"></iframe>
```

Auch andere Dienste funktionieren, wenn du ihren `<iframe>`-Einbettungscode in ein `[!embed]` packst.

Fremde Player laden erst nach einem Klick auf „Abspielen“ (Datenschutz). Abschalten mit `zwei_klick: false` in [[Einstellungen]].

---

## Hinweiskästen

```
> [!note] Hinweis
> Die Arbeit kann ausgeliehen werden.
```

Auch `[!tip]`, `[!warning]` und alle anderen Obsidian-Callouts werden als Kasten gezeigt.

---

## Seiten und CV

- Neue Seite: Notiz in `Seiten` anlegen. Damit sie in der Navigation erscheint, ihren Namen in [[Einstellungen]] unter `navigation` eintragen.
- **CV:** Einträge, die mit einer Jahreszahl beginnen, bekommen eine eigene Jahresspalte:

```
## Ausstellungen
- 2026 · Titel, Ort
- 2018–2024 · Studium, Hochschule
- seit 2025 · Mitglied im Kunstverein
```

Als Trenner nach der Jahreszahl gehen `·`, `|`, `,`, `:` oder ` – `.

---

## Zweisprachig

1. In [[Einstellungen]] bei `sprachen` beide eintragen, z.B. `de` und `en`. Die erste ist die Hauptsprache.
2. Neben jede Notiz eine Übersetzung mit Sprachkürzel legen: `Resonanzraum.md` → `Resonanzraum.en.md`.
3. In der Übersetzung nur die Eigenschaften eintragen, die sich ändern (z.B. `art`, `material`), und den übersetzten Text.

Fehlt eine Übersetzung, erscheint die Notiz in der Hauptsprache. Die englische Fassung liegt dann unter `/en/…`, und oben auf der Website erscheint ein Sprachumschalter.

---

## Gestaltung

Das Aussehen steuerst du in [[Gestaltung]]. Am einfachsten geht es in der Vorschau: unten auf **„Aa Gestaltung“** klicken. Jede Änderung ist sofort sichtbar. **Speichern** schreibt die Werte in `Gestaltung.md`.

### Vorlagen
Eine Vorlage setzt alles auf einmal. Jede weitere Eigenschaft überschreibt sie.

- `weiss` – White Cube – neutral, klar
- `galerie` – Galerie – warm, ruhig, Serifentitel
- `editorial` – Editorial – Zeitschrift, Serife, Werkliste
- `brutal` – Brutal – Mono, Versalien, harte Kanten
- `nacht` – Nacht – dunkel, Seitenleiste
- `signal` – Signal – Farbe, laut, Display-Schrift
- `studio` – Studio – technisch, Raster, Mono-Details

```yaml
vorlage: editorial
farben:
  akzent: "#e4002b"
schrift_titel: syne
```

### Alle Eigenschaften

| Eigenschaft | Möglich | Wirkung |
|---|---|---|
| `farben: hintergrund` | `"#ff0000"` | Hintergrund |
| `farben: text` | `"#ff0000"` | Text |
| `farben: akzent` | `"#ff0000"` | Akzent (Links, Hover) |
| `farben: linien` | `"#ff0000"` | Linien |
| `farben: flaeche` | `"#ff0000"` | Flächen (Platzhalter, Kästen) |
| `dunkelmodus` | `aus` · `auto` | Dunkelmodus |
| `schrift_text` | siehe unten | Schrift für Text |
| `schrift_titel` | siehe unten | Schrift für Titel |
| `schriftgroesse` | 13–26px | Schriftgröße Text |
| `titelgroesse` | `klein` · `mittel` · `gross` · `riesig` | Titelgröße |
| `titel_staerke` | 100–900 | Titel: Strichstärke |
| `titel_laufweite` | `eng` · `normal` · `weit` | Titel: Laufweite |
| `titel_versalien` | `true` · `false` | Titel in Versalien |
| `zeilenabstand` | `eng` · `normal` · `weit` | Zeilenabstand |
| `links` | `unterstrichen` · `farbig` · `dezent` | Links |
| `kopfzeile` | `zeile` · `zentriert` · `gross` · `seitlich` | Kopfzeile |
| `abstaende` | `eng` · `normal` · `weit` | Abstände |
| `seitenbreite` | `schmal` · `normal` · `voll` | Seitenbreite |
| `ecken` | 0–32px | Runde Ecken (Bilder, Kästen) |
| `bewegung` | `true` · `false` | Sanftes Einblenden |
| `uebersicht` | `raster` · `liste` · `index` | Werkübersicht |
| `kachelformat` | `quer` · `quadrat` · `hoch` · `original` | Bildformat der Kacheln |
| `kacheltext` | `unten` · `hover` · `aus` | Text der Kacheln |

### Schriften
Alle Schriften stehen unter freier Lizenz (SIL Open Font License) und werden von deiner eigenen Website ausgeliefert, nicht von Google. Es werden nur die gewählten Schriften veröffentlicht.

- **Grotesk:** `inter`, `instrument-sans`, `dm-sans`, `hanken-grotesk`, `space-grotesk`, `archivo`
- **Display:** `bricolage-grotesque`, `syne`, `unbounded`
- **Serif:** `fraunces`, `newsreader`, `eb-garamond`, `source-serif`, `playfair-display`, `instrument-serif`
- **Mono:** `jetbrains-mono`, `ibm-plex-mono`, `space-mono`
- **System:** `system`, `helvetica`, `system-serif`, `system-mono`

**Eigene Schrift:** Schriftdatei (`.woff2`, `.woff`, `.ttf` oder `.otf`) in den Vault legen, z.B. in einen Ordner `Schriften`, dann eintragen: `schrift_titel: "[[MeineSchrift.woff2]]"`. Achte auf die Lizenz: Die Datei wird mit der Website veröffentlicht und braucht eine Web-Lizenz.

### Dunkelmodus
`dunkelmodus: auto` passt die Farben an, wenn das Gerät auf dunkel eingestellt ist. Eigene Farben dafür:

```yaml
farben_dunkel:
  hintergrund: "#111111"
  text: "#eeeeee"
  akzent: "#ff7a59"
```

### Noch mehr
Alles Weitere (Abstände, Schriftgrößen im Detail, eigene Effekte) steht in der Datei `src/lib/styles/theme.css` im Projektordner.

---

## Layout

Das Layout bearbeitest du nicht hier, sondern in der Vorschau im Browser: unten auf **„✎ Layout bearbeiten“** klicken. Gespeichert wird es als `….layout.json` neben der Notiz. Diese Dateien bitte nicht von Hand ändern. Löschst du eine, wird die Seite wieder automatisch angeordnet.

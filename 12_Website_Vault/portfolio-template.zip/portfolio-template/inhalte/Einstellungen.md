---
titel: Alex Beispiel
beschreibung: Alex Beispiel arbeitet mit Klang, Raum und Situationen. Portfolio mit Werken, CV und Kontakt.
sprachen:
  - de
navigation:
  - Werke
  - CV
  - Kontakt
fusszeile:
  - Impressum
  - Datenschutz
zwei_klick: true
start_titel: true
---

Diese Notiz enthält nur die **Einstellungen** der Website (oben, in den Eigenschaften).
Der Text hier unten erscheint nirgends auf der Website – du kannst ihn für eigene Notizen nutzen.

- `sprachen`: Die erste Sprache ist die Hauptsprache. Für eine zweisprachige Seite: `de` und `en` eintragen.
- `navigation` / `fusszeile`: `Werke`, `CV` oder der Name einer Notiz aus dem Ordner *Seiten*.
- `zwei_klick`: YouTube & Co. erst nach einem Klick laden (empfohlen, wegen Datenschutz).
- `start_titel`: Name groß auf der Startseite anzeigen (`true`) oder nicht (`false`).

Farben, Schriften und Aufbau stellst du in [[Gestaltung]] ein.

Mehr dazu: [[LIESMICH]]

---
title: CV
---

Alex Beispiel, born 1996 in Musterstadt. Lives and works in Kassel.

## Education
- 2018–2024 · New Media, Kunsthochschule Musterstadt
- 2022 · Exchange semester, Akademie Beispielhausen

## Solo exhibitions
- 2026 · Resonanzraum, Kunstverein Musterstadt
- 2024 · Feldaufnahmen, Projektraum Nord, Beispielhausen

## Group exhibitions (selection)
- 2025 · Hören & Sehen, Galerie am Fluss, Musterstadt
- 2024 · Rundgang, Kunsthochschule Musterstadt
- 2023 · Stille Post, Festival für Gegenwart, Beispielhausen

## Grants & awards
- 2025 · Working grant of the City of Musterstadt
- 2023 · Förderpreis für junge Kunst (shortlist)

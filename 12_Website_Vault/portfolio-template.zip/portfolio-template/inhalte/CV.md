---
titel: CV
---

Alex Beispiel, geboren 1996 in Musterstadt. Lebt und arbeitet in Kassel.

## Ausbildung
- 2018–2024 · Studium Neue Medien, Kunsthochschule Musterstadt
- 2022 · Austauschsemester, Akademie Beispielhausen

## Einzelausstellungen
- 2026 · Resonanzraum, Kunstverein Musterstadt
- 2024 · Feldaufnahmen, Projektraum Nord, Beispielhausen

## Gruppenausstellungen (Auswahl)
- 2025 · Hören & Sehen, Galerie am Fluss, Musterstadt
- 2024 · Rundgang, Kunsthochschule Musterstadt
- 2023 · Stille Post, Festival für Gegenwart, Beispielhausen

## Stipendien & Preise
- 2025 · Arbeitsstipendium der Stadt Musterstadt
- 2023 · Förderpreis für junge Kunst (Shortlist)

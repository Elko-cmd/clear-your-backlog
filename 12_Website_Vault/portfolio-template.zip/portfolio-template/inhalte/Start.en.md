Alex Beispiel works with sound, space and situations. The works are often made on site – as installations, recordings or instructions for an audience.

Currently: [[Resonanzraum]] is on view at Kunstverein Musterstadt until March.

![[portrait.jpg|Alex Beispiel in the studio, 2026]]

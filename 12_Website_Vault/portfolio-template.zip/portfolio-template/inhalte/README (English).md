# README – How to write your website

*This note does not appear on the website. Deutsch: [[LIESMICH]]*

Everything in this vault becomes the website – except notes right here at the top level (like this one) and folders or files starting with `_`.

While the preview is running (double-click `Start (Mac).command` or `Start (Windows).bat`), every change you save shows up in the browser immediately.

> The folder names are German: `Werke` = works, `Seiten` = pages, `Einstellungen` = settings, `Gestaltung` = design. Every property can be written in German **or** English – this guide uses the English names.

---

## The folders

| Place | Becomes |
|---|---|
| `Einstellungen` | Name, navigation, languages of the whole website |
| `Gestaltung` | Colours, fonts, structure – see below |
| `Start` | Home page |
| `CV` | CV at /cv |
| `Werke/…` | One work page per note, all together on the overview /werke |
| `Seiten/…` | Further pages like contact, imprint |
| `_Vorlagen/` | Templates for new notes (not on the website) |

---

## Creating a new work

1. Inside `Werke`, create a new folder named after the work.
2. Inside it, create a new note with the same name.
3. Run **"Insert template"** (Ctrl/Cmd + P → "template") and choose `Werk`.
4. Fill in the properties, write the text, drag in images. They automatically go into the sub-folder `media`.

### Properties of a work

| Property | Meaning | Example |
|---|---|---|
| `title` | Title (otherwise the file name) | `Resonanzraum` |
| `year` | Year | `2026` |
| `kind` | Genre, medium | `Sound installation` |
| `materials` | Materials, technique | `8 speakers, steel` |
| `dimensions` | Dimensions | `200 × 120 cm` |
| `duration` | Duration | `12 min` |
| `venues` | List: where shown | `- Kunstverein, 2026` |
| `details` | Your own rows: label and value | `Edition: 3 + 1 AP` |
| `cover` | Image for the overview (otherwise the first image) | `"[[photo.jpg]]"` |
| `description` | Short text for search engines and link previews | |
| `order` | Position on the overview (1 = first) | `1` |
| `slug` | Your own address instead of the automatic one | `field-recordings` |
| `publish` | `false` = don't show yet | `false` |

Without `order`, works are sorted by year, newest first.

---

## Text

Normal Markdown works: `**bold**`, `*italic*`, lists, links, tables, `==highlight==`.

- `## Heading` or a horizontal rule `---` starts a **new block** that you can place individually in the layout.
- `[[Other note]]` links to a work or page. If the target isn't public, only the text remains.
- `%% private %%` – everything between the `%%` does **not** appear on the website.
- `^name` at the end of a paragraph gives the text block a fixed ID. Then the layout stays intact even if you add new sections before it.

---

## Images

```
![[photo.jpg]]
![[photo.jpg|Caption. Photo: Name]]
```

Several images **directly below each other, without an empty line** → **gallery** (clicking opens a large view):

```
![[detail-1.jpg]]
![[detail-2.jpg]]
![[detail-3.jpg]]
```

Or as a gallery with a shared caption:

```
> [!gallery] Installation, March 2026
> ![[setup-1.jpg]]
> ![[setup-2.jpg]]
```

Allowed: JPG, PNG, WebP, AVIF, TIFF, GIF, SVG. Please export iPhone photos (HEIC) as JPG first. Large images are no problem: the website creates smaller versions automatically.

---

## Audio, video, PDF

```
![[recording.mp3|Excerpt, 3 min]]
![[clip.mp4|Video excerpt]]
![[catalogue.pdf|Catalogue (PDF)]]
```

Audio: MP3, WAV, OGG, M4A, FLAC. Video: ideally MP4 (H.264). **Better upload long videos to Vimeo or YouTube** and insert the link. GitHub doesn't accept files over 100 MB.

---

## YouTube, Vimeo, Bandcamp & co.

Put the link **on a line of its own**:

```
https://www.youtube.com/watch?v=…
https://vimeo.com/123456789
https://soundcloud.com/name/track
https://open.spotify.com/album/…
https://www.mixcloud.com/name/show/
https://archive.org/details/…
https://name.bandcamp.com/album/title
```

With a caption:

```
> [!embed] Live recording, Kassel 2025
> https://vimeo.com/123456789
```

**Bandcamp:** If the normal link doesn't work, click **Share/Embed** in Bandcamp, copy the code and insert it like this:

```
> [!embed] Album
> <iframe src="https://bandcamp.com/EmbeddedPlayer/album=123456/…"></iframe>
```

Other services work too if you put their `<iframe>` embed code into an `[!embed]`.

Third-party players only load after a click on "Play" (privacy). Turn off with `consent: false` in [[Einstellungen]].

---

## Info boxes

```
> [!note] Note
> The work is available for loan.
```

`[!tip]`, `[!warning]` and all other Obsidian callouts are shown as a box too.

---

## Pages and CV

- New page: create a note in `Seiten`. To show it in the navigation, add its name under `navigation` in [[Einstellungen]].
- **CV:** entries starting with a year get their own year column:

```
## Exhibitions
- 2026 · Title, place
- 2018–2024 · Studies, university
- since 2025 · Member of the Kunstverein
```

Separators after the year can be `·`, `|`, `,`, `:` or ` – `.

---

## Bilingual

1. In [[Einstellungen]], enter both under `languages`, e.g. `de` and `en`. The first is the main language.
2. Put a translation with a language code next to each note: `Resonanzraum.md` → `Resonanzraum.en.md`.
3. In the translation, only enter the properties that change (e.g. `kind`, `materials`) and the translated text.

If a translation is missing, the note appears in the main language. The English version then lives under `/en/…`, and a language switch appears at the top of the website.

---

## Design

You control the look in [[Gestaltung]]. The easiest way is in the preview: click **"Aa Design"** at the bottom. Every change is visible instantly. **Save** writes the values into `Gestaltung.md`.

### Presets
A preset sets everything at once. Every further property overrides it.

- `weiss` – White Cube – neutral, clear
- `galerie` – Gallery – warm, calm, serif titles
- `editorial` – Editorial – magazine, serif, works list
- `brutal` – Brutal – mono, capitals, hard edges
- `nacht` – Night – dark, sidebar
- `signal` – Signal – colour, loud, display type
- `studio` – Studio – technical, grid, mono details

```yaml
preset: editorial
colors:
  accent: "#e4002b"
font_title: syne
```

### All properties
(German names work too, see [[LIESMICH]].)

| Property | Possible | Effect |
|---|---|---|
| `colors: background` | `"#ff0000"` | Background |
| `colors: text` | `"#ff0000"` | Text |
| `colors: accent` | `"#ff0000"` | Accent (links, hover) |
| `colors: lines` | `"#ff0000"` | Lines |
| `colors: surface` | `"#ff0000"` | Surfaces (placeholders, boxes) |
| `dark_mode` | `off` · `auto` | Dark mode |
| `font_text` | see below | Body font |
| `font_title` | see below | Title font |
| `font_size` | 13–26px | Body size |
| `title_size` | `small` · `medium` · `large` · `huge` | Title size |
| `title_weight` | 100–900 | Title weight |
| `title_tracking` | `tight` · `normal` · `wide` | Title tracking |
| `title_caps` | `true` · `false` | Titles in capitals |
| `line_height` | `tight` · `normal` · `loose` | Line height |
| `links` | `underline` · `colour` · `subtle` | Links |
| `header` | `row` · `centered` · `large` · `sidebar` | Header |
| `spacing` | `tight` · `normal` · `wide` | Spacing |
| `page_width` | `narrow` · `normal` · `full` | Page width |
| `corners` | 0–32px | Rounded corners (images, boxes) |
| `motion` | `true` · `false` | Gentle fade-in |
| `overview` | `grid` · `list` · `index` | Works overview |
| `tile_format` | `landscape` · `square` · `portrait` · `original` | Tile image format |
| `tile_text` | `below` · `hover` · `none` | Tile text |

### Fonts
All fonts are freely licensed (SIL Open Font License) and served by your own website, not by Google. Only the chosen fonts are published.

- **Sans:** `inter`, `instrument-sans`, `dm-sans`, `hanken-grotesk`, `space-grotesk`, `archivo`
- **Display:** `bricolage-grotesque`, `syne`, `unbounded`
- **Serif:** `fraunces`, `newsreader`, `eb-garamond`, `source-serif`, `playfair-display`, `instrument-serif`
- **Mono:** `jetbrains-mono`, `ibm-plex-mono`, `space-mono`
- **System:** `system`, `helvetica`, `system-serif`, `system-mono`

**Your own font:** put the font file (`.woff2`, `.woff`, `.ttf` or `.otf`) into the vault, e.g. into a folder `Fonts`, then enter: `font_title: "[[MyFont.woff2]]"`. Mind the licence: the file is published with the website and needs a web licence.

### Dark mode
`dark_mode: auto` adjusts the colours when the device is set to dark. Your own colours for it:

```yaml
dark_colors:
  background: "#111111"
  text: "#eeeeee"
  accent: "#ff7a59"
```

### Even more
Everything else (spacing, detailed font sizes, your own effects) lives in the file `src/lib/styles/theme.css` in the project folder.

---

## Layout

You don't edit the layout here but in the browser preview: click **"✎ Edit layout"** at the bottom. It's saved as `….layout.json` next to the note. Please don't edit these files by hand. If you delete one, the page is arranged automatically again.

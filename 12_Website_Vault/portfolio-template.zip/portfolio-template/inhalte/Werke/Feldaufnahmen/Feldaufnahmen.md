---
titel: Feldaufnahmen I–IV
slug: feldaufnahmen
jahr: 2024
art: Audioarbeit, Partitur
dauer: 4 × 20 min
titelbild: "[[feldaufnahmen-cover.jpg]]"
orte:
  - Projektraum Nord, Beispielhausen, 2024
angaben:
  Auflage: 3 + 1 AP
  Format: Stereo, 48 kHz
---

Vier Aufnahmen an vier Orten, jeweils zur selben Uhrzeit. Die Partitur beschreibt, wann das Mikrofon bewegt wird – sonst nichts.

![[feldaufnahme-II.mp3|Feldaufnahme II (Auszug)]]

![[mikrofon.jpg|Aufnahmesituation]]

![[partitur.pdf|Partitur (PDF, 2 Seiten)]]

## Video
Ein Video kann mit einem einfachen Link eingefügt werden – er muss allein in einer Zeile stehen:

https://www.youtube.com/watch?v=aqz-KE-bpKQ

*Beispielvideo: „Big Buck Bunny“, Blender Foundation, CC BY.*

---
titel: Resonanzraum
jahr: 2026
art: Klanginstallation
material: 8 Lautsprecher, Stahl, 8-Kanal-Audio
masse: raumgreifend, ca. 9 × 6 m
dauer: 42 min (Loop)
orte:
  - Kunstverein Musterstadt, 2026
  - Rundgang, Kunsthochschule Musterstadt, 2024
titelbild: "[[resonanzraum-01.jpg]]"
reihenfolge: 1
---

Acht Lautsprecher stehen im Kreis und spielen die Eigenfrequenzen des Raumes zurück, in dem sie stehen. Über die Dauer der Ausstellung verschiebt sich der Klang mit jedem Schritt, mit jeder Person, die den Raum betritt.

Die Arbeit wurde vor Ort entwickelt: Eine Woche lang wurde der leere Raum mit Sinustönen „abgetastet“ und aufgenommen.

![[resonanzraum-01.jpg|Ausstellungsansicht, Kunstverein Musterstadt 2026. Foto: Kim Muster]]

![[resonanzraum-02.jpg|Detail]]
![[resonanzraum-03.jpg|Messung der Raumresonanz]]
![[resonanzraum-04.jpg|Aufbau]]

![[resonanzraum-auszug.mp3|Auszug, Stereo-Mixdown]]

> [!embed] Dokumentation der Ausstellung (Beispielvideo: „Big Buck Bunny“, Blender Foundation, CC BY)
> https://vimeo.com/1084537

## Credits
Mit Unterstützung des Kunstvereins Musterstadt. Technik: Sam Beispiel.

%% Private Notiz: Erscheint nicht auf der Website. Leihgabe der Lautsprecher bis 31.3. klären. %%

---
title: Resonanzraum
kind: Sound installation
materials: 8 speakers, steel, 8-channel audio
dimensions: site-specific, approx. 9 × 6 m
duration: 42 min (loop)
venues:
  - Kunstverein Musterstadt, 2026
  - Rundgang, Kunsthochschule Musterstadt, 2024
---

Eight speakers stand in a circle, playing back the resonant frequencies of the room they are in. Over the course of the exhibition the sound shifts with every step, with every person entering the room.

The work was developed on site: for one week the empty room was "scanned" with sine tones and recorded.

![[resonanzraum-01.jpg|Installation view, Kunstverein Musterstadt 2026. Photo: Kim Muster]]

![[resonanzraum-02.jpg|Detail]]
![[resonanzraum-03.jpg|Measuring the room resonance]]
![[resonanzraum-04.jpg|Installation]]

![[resonanzraum-auszug.mp3|Excerpt, stereo mixdown]]

> [!embed] Exhibition documentation (example video: "Big Buck Bunny", Blender Foundation, CC BY)
> https://vimeo.com/1084537

## Credits
Supported by Kunstverein Musterstadt. Technical support: Sam Beispiel.

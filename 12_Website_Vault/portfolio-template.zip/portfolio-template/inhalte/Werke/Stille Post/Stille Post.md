---
titel: Stille Post
jahr: 2023
art: Performance
dauer: ca. 60 min
orte:
  - Festival für Gegenwart, Beispielhausen, 2023
---

Zwölf Personen geben einen Satz weiter, den keine von ihnen vollständig hört. ^intro

![[stille-post-01.jpg|Performance, Festival für Gegenwart 2023]]

---

Die Performance dauert so lange, bis der Satz bei der letzten Person ankommt – oder verloren geht. Das Publikum kann sich frei bewegen und Teil der Kette werden. ^ablauf

![[stille-post-ausschnitt.mp4|Videoausschnitt, 8 Sek.]]

![[stille-post-02.jpg]]

> [!note] Hinweis
> Die Performance kann für andere Orte neu eingerichtet werden. Anfragen gerne über [[Kontakt]].

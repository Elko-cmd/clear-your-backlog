---
titel: Notation (Entwurf)
jahr: 2026
veroeffentlichen: false
---

Diese Notiz ist mit `veroeffentlichen: false` markiert und erscheint deshalb **nicht** auf der Website.
So kannst du an neuen Werken arbeiten, bevor sie sichtbar werden.

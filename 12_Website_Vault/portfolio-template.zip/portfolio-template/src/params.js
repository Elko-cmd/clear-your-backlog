// DE: Erkennt Sprachkürzel am Anfang der Adresse (z.B. /en/werke/…).
// EN: Recognises language codes at the start of the address (e.g. /en/werke/…).
import { defineParams } from '@sveltejs/kit/params';

const CODES = ['de', 'en', 'fr', 'es', 'it', 'nl', 'pl', 'cs', 'da', 'sv', 'nb', 'fi', 'pt', 'tr', 'el', 'hu', 'ro', 'uk', 'ru', 'ja', 'zh', 'ko', 'ar', 'he'];

export const params = defineParams({
	lang: (param) => (CODES.includes(param) ? param : undefined)
});

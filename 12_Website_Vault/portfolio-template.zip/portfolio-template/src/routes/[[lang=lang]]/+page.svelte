<script>
	import Page from '#lib/components/Page.svelte';

	let { data } = $props();
</script>

<Page {data} />

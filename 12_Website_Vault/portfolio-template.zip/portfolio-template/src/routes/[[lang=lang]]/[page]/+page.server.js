import { error } from '@sveltejs/kit';
import { getSite } from '#lib/server/content/index.js';
import { siteFor, present } from '#lib/server/page.js';

export async function load({ params }) {
	const { content } = await siteFor(params);
	const page = content.pages.find((p) => p.slug === params.page);
	if (!page) error(404, 'Not found');
	return present(page);
}

export async function entries() {
	const site = await getSite();
	return site.languages.flatMap((lang) =>
		site.byLang[lang].pages.map((p) => ({ lang: lang === site.defaultLang ? undefined : lang, page: p.slug }))
	);
}

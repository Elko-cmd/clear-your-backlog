import { error } from '@sveltejs/kit';
import { siteFor, present } from '#lib/server/page.js';

export async function load({ params }) {
	const { content } = await siteFor(params);
	if (!content.cv) error(404, 'Not found');
	return present(content.cv);
}

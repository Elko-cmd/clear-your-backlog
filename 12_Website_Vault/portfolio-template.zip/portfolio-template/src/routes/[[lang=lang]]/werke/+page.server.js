import { siteFor, present } from '#lib/server/page.js';

export async function load({ params }) {
	const { content } = await siteFor(params);
	return present(content.overview);
}

import { error } from '@sveltejs/kit';
import { getSite } from '#lib/server/content/index.js';
import { siteFor, present } from '#lib/server/page.js';

export async function load({ params }) {
	const { content } = await siteFor(params);
	const index = content.works.findIndex((w) => w.slug === params.slug);
	if (index === -1) error(404, 'Not found');

	const prev = content.works[index - 1];
	const next = content.works[index + 1];
	return {
		...present(content.works[index]),
		prev: prev ? { title: prev.title, url: prev.url } : null,
		next: next ? { title: next.title, url: next.url } : null,
		overview: content.overview.url
	};
}

// DE: Liste aller Werke für den Build (auch solche, auf die nichts verlinkt).
// EN: List of all works for the build (including ones nothing links to).
export async function entries() {
	const site = await getSite();
	return site.languages.flatMap((lang) =>
		site.byLang[lang].works.map((w) => ({ lang: lang === site.defaultLang ? undefined : lang, slug: w.slug }))
	);
}

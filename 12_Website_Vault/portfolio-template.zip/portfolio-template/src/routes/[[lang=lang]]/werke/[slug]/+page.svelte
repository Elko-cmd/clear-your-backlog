<!-- DE: Werkseite mit Links zum vorherigen/nächsten Werk. / EN: Work page with links to the previous/next work. -->
<script>
	import Page from '#lib/components/Page.svelte';
	import { t } from '#lib/i18n.js';

	let { data } = $props();
</script>

<Page {data}>
	<nav class="pager" aria-label={t(data.lang, 'works')}>
		{#if data.prev}
			<a href={data.prev.url} rel="prev"><small>← {t(data.lang, 'previous')}</small>{data.prev.title}</a>
		{:else}<span></span>{/if}
		<a href={data.overview} class="all">{t(data.lang, 'allWorks')}</a>
		{#if data.next}
			<a href={data.next.url} rel="next"><small>{t(data.lang, 'next')} →</small>{data.next.title}</a>
		{:else}<span></span>{/if}
	</nav>
</Page>

<style>
	.pager {
		display: grid;
		grid-template-columns: 1fr auto 1fr;
		gap: 1rem;
		align-items: end;
		margin-top: clamp(3rem, 8vw, 6rem);
		padding-top: 1rem;
		border-top: 1px solid var(--color-lines);
	}
	.pager a {
		text-decoration: none;
	}
	.pager small {
		display: block;
		color: var(--color-muted);
	}
	[rel='next'] {
		text-align: right;
	}
	.all {
		font-size: var(--text-small);
	}
</style>

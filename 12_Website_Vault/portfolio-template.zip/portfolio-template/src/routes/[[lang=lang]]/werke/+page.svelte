<!--
	DE: Werkübersicht. Je nach Gestaltung (`uebersicht`): frei anordenbares Raster,
	    große Liste mit Bildvorschau oder kompakter Index.
	EN: Works overview. Depending on the design (`overview`): freely arrangeable
	    grid, large list with image preview, or compact index.
-->
<script>
	import Page from '#lib/components/Page.svelte';
	import WorkList from '#lib/components/WorkList.svelte';
	import { t } from '#lib/i18n.js';
	import { designState } from '#lib/design-state.svelte.js';

	let { data } = $props();

	const mode = $derived((designState.preview ?? data.design.values).uebersicht);
	const works = $derived(data.page.blocks.map((/** @type {any} */ b) => b.data));
</script>

<!-- DE: Überschrift für Screenreader. / EN: Heading for screen readers. -->
<h1 class="visually-hidden">{t(data.lang, 'works')}</h1>

{#if mode === 'raster'}
	<Page {data} />
{:else}
	<Page {data} grid={false}>
		<WorkList {works} {mode} />
	</Page>
{/if}

// DE: Liefert Bilder, Audio, Video & PDFs aus dem Vault aus.
//     Beim Bauen wird jede Datei einmal erzeugt und in build/medien/ abgelegt.
// EN: Serves images, audio, video & PDFs from the vault.
//     During the build every file is generated once and stored in build/medien/.
import { error } from '@sveltejs/kit';
import { getSite } from '#lib/server/content/index.js';
import { registry, renderMedia, mimeOf } from '#lib/server/content/media.js';

export const prerender = true;
export const trailingSlash = 'never';

export async function entries() {
	await getSite();
	return [...registry.keys()].map((file) => ({ file }));
}

export async function GET({ params }) {
	await getSite();
	const buffer = await renderMedia(params.file);
	if (!buffer) error(404, 'Not found');
	return new Response(new Uint8Array(buffer), {
		headers: {
			'content-type': mimeOf(params.file.split('.').pop() ?? ''),
			'cache-control': 'public, max-age=3600'
		}
	});
}

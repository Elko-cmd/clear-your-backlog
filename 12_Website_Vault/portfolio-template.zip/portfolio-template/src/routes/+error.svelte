<!--
	DE: Fehlerseite. Beim Entwickeln zeigt sie genau, welche Datei ein Problem hat.
	EN: Error page. During development it shows exactly which file has a problem.
-->
<script>
	import { page } from '$app/state';
	import { dev } from '$app/env';
</script>

<svelte:head><title>{page.status}</title></svelte:head>

<section class="error">
	{#if page.status === 404}
		<h1>404</h1>
		<p>Diese Seite gibt es nicht. / This page does not exist.</p>
	{:else}
		<h1>Hoppla / Oops</h1>
		{#if page.error?.file}
			<p class="file">📄 <code>{page.error.file}</code></p>
		{/if}
		<p lang="de">{page.error?.message}</p>
		{#if page.error?.en}<p lang="en">{page.error.en}</p>{/if}
		{#if dev}
			<p class="tip">
				Datei in Obsidian korrigieren und speichern – diese Seite lädt dann von selbst neu.<br />
				Fix the file in Obsidian and save – this page then reloads by itself.
			</p>
		{/if}
	{/if}
	<p><a href="./">← Start / Home</a></p>
</section>

<style>
	.error {
		max-width: 40rem;
	}
	.file {
		font-size: var(--text-large);
	}
	.tip {
		padding: 1rem;
		background: var(--color-surface);
		font-size: var(--text-small);
	}
</style>

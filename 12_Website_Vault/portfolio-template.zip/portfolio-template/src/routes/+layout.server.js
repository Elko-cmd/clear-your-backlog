// DE: Gilt für ALLE Seiten: alles wird beim Bauen als fertiges HTML erzeugt.
// EN: Applies to ALL pages: everything is generated as finished HTML during the build.
import { dev } from '$app/env';
import { siteFor } from '#lib/server/page.js';
import { resolveDesign } from '#lib/design.js';
import config from '../../portfolio.config.js';

export const prerender = true;
export const trailingSlash = 'always';

export async function load({ params }) {
	try {
		const { site, lang, content } = await siteFor(params);
		return {
			lang,
			languages: site.languages,
			settings: content.settings,
			navigation: content.navigation,
			footer: content.footer,
			home: content.home.url,
			columns: config.columns,
			design: site.design,
			dev
		};
	} catch {
		// DE: Fehler zeigt die Seite selbst ausführlich an (src/routes/+error.svelte).
		// EN: The page itself shows the error in detail (src/routes/+error.svelte).
		const { design } = resolveDesign({});
		return {
			lang: params.lang ?? 'de',
			languages: [],
			settings: { title: 'Portfolio' },
			navigation: [],
			footer: [],
			home: '/',
			columns: config.columns,
			design: { values: design, css: '', attributes: {}, families: {}, customFonts: [], file: config.files.design },
			dev
		};
	}
}

<!--
	DE: Rahmen um jede Seite: Kopfzeile mit Navigation, Inhalt, Fußzeile.
	    Das Aussehen steht komplett in src/lib/styles/theme.css.
	EN: Frame around every page: header with navigation, content, footer.
	    The look lives entirely in src/lib/styles/theme.css.
-->
<script>
	import '#lib/styles/theme.css';
	import { page } from '$app/state';
	import { onNavigate } from '$app/navigation';
	import { t } from '#lib/i18n.js';
	import { toCss, toAttributes } from '#lib/design.js';
	import { designState } from '#lib/design-state.svelte.js';

	let { data, children } = $props();

	// DE: Während man im Gestaltungs-Panel probiert, gelten dessen Werte.
	// EN: While experimenting in the design panel, its values apply.
	const design = $derived(designState.preview ?? data.design.values);
	const css = $derived(
		designState.preview ? fontFaces(data.design.css) + toCss(design, data.design.families) : data.design.css
	);

	/** @param {string} all DE: nur die @font-face-Regeln / EN: only the @font-face rules */
	function fontFaces(all) {
		return all.match(/@font-face\s*\{[^}]*\}/g)?.join('') ?? '';
	}

	// DE: Gestaltungs-Attribute am <html> aktuell halten (für das Panel).
	// EN: Keep the design attributes on <html> up to date (for the panel).
	$effect(() => {
		for (const [key, value] of Object.entries(toAttributes(design))) {
			document.documentElement.setAttribute(key, String(value));
		}
	});

	// DE: Weiche Überblendung beim Seitenwechsel (wenn „bewegung“ an ist).
	// EN: Smooth cross-fade when changing pages (if "motion" is on).
	onNavigate((navigation) => {
		if (!design.bewegung || !document.startViewTransition) return;
		return new Promise((resolve) => {
			document.startViewTransition(async () => {
				resolve();
				await navigation.complete;
			});
		});
	});

	const alternates = $derived(/** @type {Record<string, string>} */ (page.data.page?.alternates ?? {}));
	const current = $derived(page.url.pathname);
</script>

<svelte:head>
	{@html `<style id="gestaltung">${css}</style>`}
</svelte:head>

<a class="skip" href="#inhalt">{t(data.lang, 'skip')}</a>

<header class="site-header">
	<a class="site-title" href={data.home}>{data.settings?.title}</a>

	<nav class="site-nav" aria-label={t(data.lang, 'menu')}>
		<ul>
			{#each data.navigation as item (item.url)}
				<li>
					<a href={item.url} aria-current={current.startsWith(item.url) && item.url !== data.home ? 'page' : undefined}>
						{item.label}
					</a>
				</li>
			{/each}
		</ul>

		{#if data.languages?.length > 1}
			<ul class="languages">
				{#each data.languages as lang (lang)}
					<li>
						<a href={alternates[lang] ?? data.home} hreflang={lang} {lang} aria-current={lang === data.lang ? 'true' : undefined}>
							{lang.toUpperCase()}
						</a>
					</li>
				{/each}
			</ul>
		{/if}
	</nav>
</header>

<main id="inhalt">
	{@render children()}
</main>

<footer class="site-footer">
	<span>© {new Date().getFullYear()} {data.settings?.title}</span>
	{#if data.footer?.length}
		<ul>
			{#each data.footer as item (item.url)}
				<li><a href={item.url}>{item.label}</a></li>
			{/each}
		</ul>
	{/if}
</footer>

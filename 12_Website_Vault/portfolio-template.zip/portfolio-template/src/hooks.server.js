// DE: Setzt <html lang="…"> passend zur Sprache (wichtig für Screenreader) und die
//     Gestaltungs-Attribute (data-kopfzeile="…" usw.) – schon im HTML, damit nichts flackert.
// EN: Sets <html lang="…"> to the page's language (important for screen readers) and the
//     design attributes (data-kopfzeile="…" etc.) – right in the HTML so nothing flickers.
import { getSite } from '#lib/server/content/index.js';

/** @type {import('@sveltejs/kit').Handle} */
export async function handle({ event, resolve }) {
	let lang = 'de';
	let attributes = '';
	try {
		const site = await getSite();
		const first = event.route.id?.includes('[[lang=lang]]') ? event.params.lang : undefined;
		lang = first ?? site.defaultLang;
		attributes = Object.entries(site.design.attributes)
			.map(([key, value]) => ` ${key}="${String(value).replace(/"/g, '')}"`)
			.join('');
	} catch {
		// DE: Fehler zeigt die Seite selbst an. / EN: The page itself shows errors.
	}
	return resolve(event, {
		transformPageChunk: ({ html }) => html.replace('%lang%', lang).replace('%design%', attributes)
	});
}

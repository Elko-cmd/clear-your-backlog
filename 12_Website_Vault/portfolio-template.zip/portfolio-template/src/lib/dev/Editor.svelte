<!--
	DE: LAYOUT-EDITOR – nur beim Entwickeln (`npm run dev`) sichtbar.
	    • Block ziehen          → verschieben
	    • Rand/Ecke ziehen      → Breite/Höhe ändern
	    • Pfeiltasten           → verschieben, mit Shift: Größe ändern
	    • „Speichern“ schreibt eine `.layout.json` neben die Notiz in den Vault.
	    Die Datei enthält nur Positionen, nie Text. Löschst du sie, werden die
	    Blöcke wieder automatisch angeordnet.

	EN: LAYOUT EDITOR – only visible during development (`npm run dev`).
	    • Drag a block          → move
	    • Drag edge/corner      → change width/height
	    • Arrow keys            → move, with Shift: resize
	    • "Save" writes a `.layout.json` next to the note in the vault.
	    The file only contains positions, never text. If you delete it, the
	    blocks are arranged automatically again.
-->
<script>
	import { tick } from 'svelte';
	import { beforeNavigate, refreshAll } from '$app/navigation';
	import { arrange, clamp } from '#lib/layout/arrange.js';
	import DesignPanel from './DesignPanel.svelte';

	/** @typedef {import('#lib/layout/arrange.js').Placement} Placement */

	/**
	 * @type {{
	 *   page: any,
	 *   info: { layoutFile: string, obsidian: string | null, source: string | null },
	 *   lang: string,
	 *   columns: number,
	 *   grid: HTMLElement | undefined,
	 *   placements: Record<string, Placement>,
	 *   editing: boolean,
	 *   canLayout?: boolean,
	 *   design: any
	 * }}
	 */
	let { page, info, lang, columns, grid, canLayout = true, design, placements = $bindable(), editing = $bindable() } = $props();

	// DE: Panel bleibt nach dem Neuladen offen (z.B. nach dem Speichern).
	// EN: The panel stays open after a reload (e.g. after saving).
	let designOpen = $state(readFlag());
	function readFlag() {
		try {
			return sessionStorage.getItem('portfolio-design-panel') === '1';
		} catch {
			return false;
		}
	}
	$effect(() => {
		try {
			sessionStorage.setItem('portfolio-design-panel', designOpen ? '1' : '0');
		} catch {
			/* egal / never mind */
		}
	});

	const L = $derived(lang === 'de' ? DE : EN);

	let dirty = $state(false);
	let saving = $state(false);
	let message = $state('');
	/** @type {string | null} */
	let selected = $state(null);
	let wide = $state(true);
	/** @type {Array<{ id: string, label: string, x: number, y: number, w: number, h: number }>} */
	let boxes = $state([]);

	// ─── Vermessen: wo liegen die Zellen? / measure: where are the cells? ───

	function measure() {
		if (!grid || !editing) return;
		const g = grid.getBoundingClientRect();
		boxes = page.blocks
			.map((/** @type {any} */ block) => {
				const el = grid?.querySelector(`[data-id="${CSS.escape(block.id)}"]`);
				if (!el) return null;
				const r = el.getBoundingClientRect();
				return { id: block.id, label: labelOf(block), x: r.left - g.left, y: r.top - g.top, w: r.width, h: Math.max(r.height, 24) };
			})
			.filter(Boolean);
	}

	$effect(() => {
		// DE: Neu vermessen, wenn sich Positionen oder der Modus ändern.
		// EN: Re-measure whenever positions or the mode change.
		void placements;
		void editing;
		tick().then(measure);
	});

	$effect(() => {
		if (!grid) return;
		const observer = new ResizeObserver(() => measure());
		observer.observe(grid);
		grid.querySelectorAll('.cell').forEach((cell) => observer.observe(cell));
		const media = matchMedia('(min-width: 760px)');
		const update = () => (wide = media.matches);
		update();
		media.addEventListener('change', update);
		return () => {
			observer.disconnect();
			media.removeEventListener('change', update);
		};
	});

	// ─── Rasterzelle unter dem Mauszeiger / grid cell under the pointer ───

	/** @param {number} clientX @param {number} clientY */
	function cellAt(clientX, clientY) {
		if (!grid) return { col: 1, row: 1 };
		const g = grid.getBoundingClientRect();
		const style = getComputedStyle(grid);
		const cols = style.gridTemplateColumns.split(' ').map(parseFloat);
		const rows = style.gridTemplateRows.split(' ').map(parseFloat);
		return {
			col: trackIndex(clientX - g.left, cols, parseFloat(style.columnGap) || 0),
			row: trackIndex(clientY - g.top, rows, parseFloat(style.rowGap) || 0)
		};
	}

	/** @param {number} pos @param {number[]} tracks @param {number} gap */
	function trackIndex(pos, tracks, gap) {
		let start = 0;
		for (let i = 0; i < tracks.length; i++) {
			const end = start + tracks[i];
			if (pos < end + gap / 2) return i + 1;
			start = end + gap;
		}
		return tracks.length + 1;
	}

	// ─── Ziehen / dragging ───

	/**
	 * @param {PointerEvent} event
	 * @param {string} id
	 * @param {'move' | 'x' | 'y' | 'xy'} mode
	 */
	function startDrag(event, id, mode) {
		if (event.button !== 0) return;
		event.preventDefault();
		event.stopPropagation();
		selected = id;

		const origin = { ...placements[id] };
		const from = cellAt(event.clientX, event.clientY);

		/** @param {PointerEvent} e */
		const onmove = (e) => {
			const to = cellAt(e.clientX, e.clientY);
			const next = { ...origin };
			if (mode === 'move') {
				next.col = clamp(origin.col + to.col - from.col, 1, columns - origin.span + 1);
				next.row = Math.max(1, origin.row + to.row - from.row);
			}
			if (mode === 'x' || mode === 'xy') next.span = clamp(to.col - origin.col + 1, 1, columns - origin.col + 1);
			if (mode === 'y' || mode === 'xy') next.rows = Math.max(1, to.row - origin.row + 1);
			update(id, next);
		};
		const onup = () => {
			window.removeEventListener('pointermove', onmove);
			window.removeEventListener('pointerup', onup);
		};
		window.addEventListener('pointermove', onmove);
		window.addEventListener('pointerup', onup);
	}

	/** @param {string} id @param {Placement} next */
	function update(id, next) {
		const prev = placements[id];
		if (prev.col === next.col && prev.row === next.row && prev.span === next.span && prev.rows === next.rows) return;
		placements = { ...placements, [id]: next };
		dirty = true;
		message = '';
	}

	// ─── Tastatur / keyboard ───

	/** @param {KeyboardEvent} e */
	function onkeydown(e) {
		if (!editing || !selected) return;
		if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
		const p = { ...placements[selected] };
		const step = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key];
		if (e.key === 'Escape') return void (selected = null);
		if (!step) return;
		e.preventDefault();
		if (e.shiftKey) {
			p.span = clamp(p.span + step[0], 1, columns - p.col + 1);
			p.rows = Math.max(1, p.rows + step[1]);
		} else {
			p.col = clamp(p.col + step[0], 1, columns - p.span + 1);
			p.row = Math.max(1, p.row + step[1]);
		}
		update(selected, p);
	}

	// ─── Aktionen / actions ───

	/** DE: Fügt über dem gewählten Block eine leere Zeile ein. / EN: Inserts an empty row above the selected block. */
	function insertRow() {
		if (!selected) return;
		const at = placements[selected].row;
		placements = Object.fromEntries(
			Object.entries(placements).map(([id, p]) => [id, p.row >= at ? { ...p, row: p.row + 1 } : p])
		);
		dirty = true;
	}

	function discard() {
		placements = arrange(page.blocks, page.layout, columns);
		dirty = false;
		message = '';
	}

	function auto() {
		placements = arrange(page.blocks, null, columns);
		dirty = true;
	}

	/**
	 * DE: Entfernt leere Zeilen, damit keine Lücken entstehen.
	 * EN: Removes empty rows so that no gaps remain.
	 * @param {Record<string, Placement>} all
	 */
	function compact(all) {
		const used = new Set();
		for (const p of Object.values(all)) for (let r = p.row; r < p.row + p.rows; r++) used.add(r);
		const sorted = [...used].sort((a, b) => a - b);
		const map = new Map(sorted.map((r, i) => [r, i + 1]));
		return Object.fromEntries(Object.entries(all).map(([id, p]) => [id, { ...p, row: map.get(p.row) }]));
	}

	async function save() {
		saving = true;
		const compacted = compact(placements);
		const layout = {
			version: 1,
			columns,
			// DE: Einträge anderer Sprachfassungen bleiben erhalten. / EN: Entries of other language versions are kept.
			blocks: { ...(page.layout?.blocks ?? {}), ...compacted }
		};
		try {
			const res = await fetch('/__portfolio/layout', {
				method: 'POST',
				headers: { 'content-type': 'application/json' },
				body: JSON.stringify({ file: info.layoutFile, layout })
			});
			const result = await res.json();
			if (!result.ok) throw new Error(result.message);
			dirty = false;
			message = `${L.saved} ${result.file}`;
			await refreshAll();
		} catch (error) {
			message = `${L.failed}: ${/** @type {Error} */ (error).message}`;
		} finally {
			saving = false;
		}
	}

	beforeNavigate(({ cancel }) => {
		if (dirty && !confirm(L.unsaved)) cancel();
	});

	/** @param {any} block */
	function labelOf(block) {
		const names = /** @type {Record<string, string>} */ (L.types);
		const name = block.media?.name ?? block.embed?.label ?? block.data?.title ?? block.name ?? block.id;
		return `${names[block.type] ?? block.type} · ${name}`;
	}

	/** @param {HTMLElement} node */
	function portal(node) {
		// DE: Die Rahmen liegen IM Raster, damit sie mitscrollen. / EN: The frames live INSIDE the grid so they scroll along.
		grid?.appendChild(node);
		return { destroy: () => node.remove() };
	}

	function finish() {
		if (dirty && !confirm(L.unsaved)) return;
		if (dirty) discard();
		editing = false;
		selected = null;
	}

	const DE = {
		edit: 'Layout bearbeiten',
		design: 'Gestaltung',
		done: 'Fertig',
		save: 'Speichern',
		discard: 'Verwerfen',
		auto: 'Automatisch anordnen',
		insert: 'Zeile einfügen',
		obsidian: 'In Obsidian öffnen',
		saved: 'Gespeichert:',
		failed: 'Fehler beim Speichern',
		unsaved: 'Das Layout hat ungespeicherte Änderungen. Trotzdem verlassen?',
		changes: 'Ungespeicherte Änderungen',
		narrow: 'Fenster breiter machen, um das Layout zu bearbeiten.',
		hint: 'Ziehen = verschieben · Rand ziehen = Größe · Pfeiltasten (+ Shift)',
		types: { text: 'Text', image: 'Bild', gallery: 'Galerie', audio: 'Audio', video: 'Video', pdf: 'PDF', file: 'Datei', embed: 'Einbettung', meta: 'Titel & Angaben', title: 'Titel', work: 'Werk', missing: 'Fehlt' }
	};
	const EN = {
		edit: 'Edit layout',
		design: 'Design',
		done: 'Done',
		save: 'Save',
		discard: 'Discard',
		auto: 'Arrange automatically',
		insert: 'Insert row',
		obsidian: 'Open in Obsidian',
		saved: 'Saved:',
		failed: 'Saving failed',
		unsaved: 'The layout has unsaved changes. Leave anyway?',
		changes: 'Unsaved changes',
		narrow: 'Make the window wider to edit the layout.',
		hint: 'Drag = move · drag edge = resize · arrow keys (+ Shift)',
		types: { text: 'Text', image: 'Image', gallery: 'Gallery', audio: 'Audio', video: 'Video', pdf: 'PDF', file: 'File', embed: 'Embed', meta: 'Title & details', title: 'Title', work: 'Work', missing: 'Missing' }
	};
</script>

<svelte:window {onkeydown} onresize={measure} />

{#if editing && wide}
	<div class="overlay" use:portal>
		{#each boxes as box (box.id)}
			<!-- svelte-ignore a11y_no_static_element_interactions -->
			<div
				class="box"
				class:selected={selected === box.id}
				style:left="{box.x}px"
				style:top="{box.y}px"
				style:width="{box.w}px"
				style:height="{box.h}px"
				onpointerdown={(e) => startDrag(e, box.id, 'move')}
			>
				<span class="label">{box.label}</span>
				<span class="handle x" onpointerdown={(e) => startDrag(e, box.id, 'x')}></span>
				<span class="handle y" onpointerdown={(e) => startDrag(e, box.id, 'y')}></span>
				<span class="handle xy" onpointerdown={(e) => startDrag(e, box.id, 'xy')}></span>
			</div>
		{/each}
	</div>
{/if}

{#if designOpen}
	<DesignPanel {design} {lang} onclose={() => (designOpen = false)} />
{/if}

<div class="toolbar" role="toolbar">
	{#if !editing}
		{#if canLayout}
			<button type="button" class="primary" onclick={() => (editing = true)}>✎ {L.edit}</button>
		{/if}
		<button type="button" class:active={designOpen} onclick={() => (designOpen = !designOpen)}>Aa {L.design}</button>
		{#if info.obsidian}<a href={info.obsidian}>{L.obsidian}</a>{/if}
	{:else}
		<button type="button" class="primary" disabled={!dirty || saving} onclick={save}>{L.save}</button>
		<button type="button" disabled={!dirty} onclick={discard}>{L.discard}</button>
		<button type="button" onclick={auto}>{L.auto}</button>
		<button type="button" disabled={!selected} onclick={insertRow}>{L.insert}</button>
		<button type="button" onclick={finish}>{L.done}</button>
		<span class="status">
			{#if !wide}{L.narrow}{:else if message}{message}{:else if dirty}● {L.changes}{:else}{L.hint}{/if}
		</span>
		<code class="file">{info.layoutFile}</code>
	{/if}
</div>

<style>
	.overlay {
		position: absolute;
		inset: 0;
		pointer-events: none;
		z-index: 1000;
	}
	.box {
		position: absolute;
		pointer-events: auto;
		cursor: grab;
		outline: 1px dashed #1f3dff;
		outline-offset: 2px;
		background: rgb(31 61 255 / 0.06);
		touch-action: none;
	}
	.box:hover {
		background: rgb(31 61 255 / 0.12);
	}
	.box.selected {
		outline: 2px solid #1f3dff;
		background: rgb(31 61 255 / 0.1);
		z-index: 1;
	}
	.box:active {
		cursor: grabbing;
	}
	.label {
		position: absolute;
		top: -0.1rem;
		left: -0.1rem;
		max-width: 100%;
		padding: 0.15rem 0.4rem;
		overflow: hidden;
		background: #1f3dff;
		color: #fff;
		font: 11px/1.3 ui-monospace, Menlo, monospace;
		white-space: nowrap;
		text-overflow: ellipsis;
		pointer-events: none;
	}
	.handle {
		position: absolute;
		background: #1f3dff;
		opacity: 0;
	}
	.box:hover .handle,
	.box.selected .handle {
		opacity: 1;
	}
	.handle.x {
		top: 50%;
		right: -6px;
		width: 8px;
		height: 40px;
		margin-top: -20px;
		cursor: ew-resize;
	}
	.handle.y {
		left: 50%;
		bottom: -6px;
		width: 40px;
		height: 8px;
		margin-left: -20px;
		cursor: ns-resize;
	}
	.handle.xy {
		right: -7px;
		bottom: -7px;
		width: 12px;
		height: 12px;
		cursor: nwse-resize;
	}

	.toolbar {
		position: fixed;
		left: 50%;
		bottom: 1rem;
		z-index: 2000;
		transform: translateX(-50%);
		display: flex;
		flex-wrap: wrap;
		align-items: center;
		gap: 0.4rem 0.6rem;
		max-width: calc(100vw - 2rem);
		padding: 0.5rem;
		background: #111;
		color: #eee;
		font: 13px/1.3 system-ui, sans-serif;
		box-shadow: 0 6px 30px rgb(0 0 0 / 0.25);
		border-radius: 8px;
	}
	.toolbar button {
		padding: 0.45rem 0.8rem;
		border: 1px solid #444;
		border-radius: 5px;
		background: #222;
		color: inherit;
		font: inherit;
		cursor: pointer;
	}
	.toolbar button:hover:not(:disabled) {
		border-color: #888;
	}
	.toolbar button:disabled {
		opacity: 0.4;
		cursor: default;
	}
	.toolbar .active {
		background: #eee;
		color: #111;
	}
	.toolbar .primary {
		background: #1f3dff;
		border-color: #1f3dff;
		color: #fff;
	}
	.toolbar a {
		color: #aab4ff;
		padding-inline: 0.4rem;
	}
	.status {
		padding-inline: 0.4rem;
		color: #bbb;
	}
	.file {
		color: #777;
		font-size: 11px;
	}
</style>

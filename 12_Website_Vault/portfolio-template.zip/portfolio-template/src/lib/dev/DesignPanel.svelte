<!--
	DE: GESTALTUNGS-PANEL – nur in der Vorschau (`npm run dev`).
	    Jede Änderung ist sofort auf der Seite sichtbar. „Speichern“ schreibt die
	    Werte in `inhalte/Gestaltung.md` – dort kannst du sie auch in Obsidian ändern.
	    Gespeichert wird nur, was von der gewählten Vorlage abweicht.
	    Die Bedienelemente entstehen automatisch aus OPTIONS in src/lib/design.js.

	EN: DESIGN PANEL – only in the preview (`npm run dev`).
	    Every change is visible on the page instantly. "Save" writes the values
	    into `inhalte/Gestaltung.md` – you can also change them there in Obsidian.
	    Only what differs from the chosen preset is saved.
	    The controls are generated automatically from OPTIONS in src/lib/design.js.
-->
<script>
	import { OPTIONS, PRESETS, FONTS, SYSTEM_FONTS, resolveDesign, diffFromPreset } from '#lib/design.js';
	import { designState } from '#lib/design-state.svelte.js';

	/** @type {{ design: any, lang: string, onclose: () => void }} */
	let { design, lang, onclose } = $props();

	const de = $derived(lang === 'de');
	const i = $derived(de ? 0 : 1);

	// svelte-ignore state_referenced_locally
	let values = $state(structuredClone(design.values));
	let dirty = $state(false);
	let saving = $state(false);
	let message = $state('');

	const GROUPS = [
		['farben', 'Farben', 'Colours'],
		['schrift', 'Schrift', 'Type'],
		['aufbau', 'Aufbau', 'Structure'],
		['werke', 'Werkübersicht', 'Works overview']
	];

	const KINDS = [
		['sans', 'Grotesk / Sans', 'Sans'],
		['display', 'Display', 'Display'],
		['serif', 'Serif', 'Serif'],
		['mono', 'Mono', 'Mono']
	];

	function changed() {
		dirty = true;
		message = '';
		designState.preview = $state.snapshot(values);
	}

	/** @param {string} name */
	function choosePreset(name) {
		values = resolveDesign({ vorlage: name }).design;
		changed();
	}

	function discard() {
		values = structuredClone(design.values);
		designState.preview = null;
		dirty = false;
	}

	async function save() {
		saving = true;
		try {
			const res = await fetch('/__portfolio/design', {
				method: 'POST',
				headers: { 'content-type': 'application/json' },
				body: JSON.stringify({ file: design.file, values: diffFromPreset($state.snapshot(values)) })
			});
			const result = await res.json();
			if (!result.ok) throw new Error(result.message);
			dirty = false;
			message = `${de ? 'Gespeichert:' : 'Saved:'} ${result.file}`;
			// DE: Die Seite lädt gleich neu (Gestaltung.md hat sich geändert).
			// EN: The page reloads in a moment (Gestaltung.md has changed).
		} catch (error) {
			message = `${de ? 'Fehler' : 'Error'}: ${/** @type {Error} */ (error).message}`;
		} finally {
			saving = false;
		}
	}

	/** @param {string} v */
	const isHex = (v) => /^#[0-9a-f]{6}$/i.test(v ?? '');

	/** @param {string} id */
	function familyOf(id) {
		const system = /** @type {Record<string, any>} */ (SYSTEM_FONTS)[id];
		if (system) return system.stack;
		return design.families[id] ? `'${design.families[id]}'` : 'inherit';
	}
</script>

<aside class="panel" aria-label={de ? 'Gestaltung' : 'Design'}>
	<header>
		<strong>Aa {de ? 'Gestaltung' : 'Design'}</strong>
		<button type="button" class="close" onclick={onclose} aria-label={de ? 'Schließen' : 'Close'}>×</button>
	</header>

	<section>
		<h3>{de ? 'Vorlage' : 'Preset'}</h3>
		<div class="presets">
			{#each Object.entries(PRESETS) as [name, preset] (name)}
				<button type="button" class:current={values.vorlage === name} onclick={() => choosePreset(name)}>
					<span class="swatch" style:background={preset.values.farben?.hintergrund ?? '#fff'} style:color={preset.values.farben?.text ?? '#111'}>
						<span style:background={preset.values.farben?.akzent ?? '#0047ff'}></span>
						Aa
					</span>
					<span class="preset-label">{preset.label[i]}</span>
				</button>
			{/each}
		</div>
		<p class="hint">
			{de
				? 'Eine Vorlage setzt alle Werte. Danach kannst du unten einzelne ändern.'
				: 'A preset sets all values. Afterwards you can change single ones below.'}
		</p>
	</section>

	{#each GROUPS as [group, labelDe, labelEn] (group)}
		<section>
			<h3>{de ? labelDe : labelEn}</h3>

			{#each OPTIONS.filter((o) => o.group === group) as option (option.key)}
				<div class="row" class:wide={option.type === 'font'}>
					<label for="opt-{option.key}">{option.label[i]}</label>

					{#if option.type === 'color'}
						<span class="color">
							<input
								type="color"
								value={isHex(values.farben[option.key]) ? values.farben[option.key] : '#000000'}
								oninput={(e) => {
									values.farben[option.key] = e.currentTarget.value;
									changed();
								}}
								aria-label={option.label[i]}
							/>
							<input
								id="opt-{option.key}"
								type="text"
								bind:value={values.farben[option.key]}
								oninput={changed}
								spellcheck="false"
							/>
						</span>
					{:else if option.type === 'font'}
						<select id="opt-{option.key}" bind:value={values[option.key]} onchange={changed}>
							{#each KINDS as [kind, kDe, kEn] (kind)}
								<optgroup label={de ? kDe : kEn}>
									{#each Object.entries(FONTS).filter(([, f]) => f.kind === kind) as [id, font] (id)}
										<option value={id}>{font.label}</option>
									{/each}
								</optgroup>
							{/each}
							<optgroup label={de ? 'Systemschriften' : 'System fonts'}>
								{#each Object.entries(SYSTEM_FONTS) as [id, font] (id)}
									<option value={id}>{font.label}</option>
								{/each}
							</optgroup>
							{#if design.customFonts.length}
								<optgroup label={de ? 'Eigene Dateien im Vault' : 'Own files in the vault'}>
									{#each design.customFonts as name (name)}
										<option value={name}>{name}</option>
									{/each}
								</optgroup>
							{/if}
						</select>
						<span class="sample" style:font-family={familyOf(values[option.key])}>
							Hamburgefonstiv 0123 &amp; Äß
						</span>
					{:else if option.type === 'number'}
						<span class="range">
							<input
								id="opt-{option.key}"
								type="range"
								min={option.min}
								max={option.max}
								step={option.step}
								bind:value={values[option.key]}
								oninput={changed}
							/>
							<output>{values[option.key]}{option.unit ?? ''}</output>
						</span>
					{:else if option.type === 'bool'}
						<input id="opt-{option.key}" type="checkbox" bind:checked={values[option.key]} onchange={changed} />
					{:else}
						<select id="opt-{option.key}" bind:value={values[option.key]} onchange={changed}>
							{#each option.values ?? [] as [value, labelDe, labelEn] (value)}
								<option {value}>{de ? labelDe : labelEn}</option>
							{/each}
						</select>
					{/if}
				</div>
			{/each}
		</section>
	{/each}

	<footer>
		<div class="buttons">
			<button type="button" class="primary" disabled={!dirty || saving} onclick={save}>{de ? 'Speichern' : 'Save'}</button>
			<button type="button" disabled={!dirty} onclick={discard}>{de ? 'Verwerfen' : 'Discard'}</button>
		</div>
		<p class="hint">
			{#if message}{message}{:else if dirty}● {de ? 'Ungespeicherte Änderungen' : 'Unsaved changes'}{:else}
				{de ? 'Wird gespeichert in' : 'Saved to'} <code>{design.file}</code>{/if}
		</p>
	</footer>
</aside>

<style>
	.panel {
		position: fixed;
		inset: 0 0 0 auto;
		z-index: 2500;
		width: min(360px, 100vw);
		overflow-y: auto;
		background: #141414;
		color: #e6e6e6;
		font: 13px/1.4 system-ui, sans-serif;
		box-shadow: -10px 0 40px rgb(0 0 0 / 0.25);
		overscroll-behavior: contain;
	}
	header,
	footer {
		position: sticky;
		z-index: 1;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0.8rem 1rem;
		background: #141414;
	}
	header {
		top: 0;
		border-bottom: 1px solid #2a2a2a;
	}
	footer {
		bottom: 0;
		flex-direction: column;
		align-items: stretch;
		gap: 0.4rem;
		border-top: 1px solid #2a2a2a;
	}
	section {
		padding: 0.9rem 1rem 1rem;
		border-bottom: 1px solid #222;
	}
	h3 {
		margin: 0 0 0.7rem;
		font: 600 11px/1 system-ui, sans-serif;
		letter-spacing: 0.08em;
		text-transform: uppercase;
		color: #8a8a8a;
	}
	.row {
		display: grid;
		grid-template-columns: 1fr 1.15fr;
		gap: 0.6rem;
		align-items: center;
		margin-bottom: 0.55rem;
	}
	.row.wide {
		grid-template-columns: 1fr;
		gap: 0.3rem;
	}
	label {
		color: #c8c8c8;
	}
	select,
	input[type='text'] {
		width: 100%;
		padding: 0.35rem 0.45rem;
		border: 1px solid #383838;
		border-radius: 4px;
		background: #1e1e1e;
		color: inherit;
		font: inherit;
	}
	input[type='text'] {
		font-family: ui-monospace, Menlo, monospace;
		font-size: 12px;
	}
	.color {
		display: flex;
		gap: 0.4rem;
	}
	input[type='color'] {
		flex: none;
		width: 2rem;
		height: 1.9rem;
		padding: 0;
		border: 1px solid #383838;
		border-radius: 4px;
		background: none;
		cursor: pointer;
	}
	.range {
		display: flex;
		gap: 0.5rem;
		align-items: center;
	}
	.range input {
		flex: 1;
		min-width: 0;
		accent-color: #6f86ff;
	}
	output {
		min-width: 3.2em;
		text-align: right;
		font-variant-numeric: tabular-nums;
		color: #aaa;
	}
	input[type='checkbox'] {
		justify-self: start;
		width: 1.1rem;
		height: 1.1rem;
		accent-color: #6f86ff;
	}
	.sample {
		padding: 0.15rem 0 0.4rem;
		font-size: 20px;
		line-height: 1.2;
		color: #fff;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}
	.presets {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 0.5rem;
	}
	.presets button {
		display: grid;
		gap: 0.35rem;
		padding: 0.4rem;
		border: 1px solid #333;
		border-radius: 6px;
		background: #1b1b1b;
		color: inherit;
		font: inherit;
		text-align: left;
		cursor: pointer;
	}
	.presets button:hover {
		border-color: #666;
	}
	.presets button.current {
		border-color: #6f86ff;
		box-shadow: 0 0 0 1px #6f86ff;
	}
	.swatch {
		position: relative;
		display: flex;
		align-items: flex-end;
		height: 2.6rem;
		padding: 0.25rem 0.4rem;
		border-radius: 3px;
		font: 600 18px/1 Georgia, serif;
	}
	.swatch span {
		position: absolute;
		top: 0.35rem;
		right: 0.35rem;
		width: 0.7rem;
		height: 0.7rem;
		border-radius: 50%;
	}
	.preset-label {
		font-size: 11px;
		line-height: 1.25;
		color: #aaa;
	}
	.hint {
		margin: 0.6rem 0 0;
		font-size: 11.5px;
		color: #888;
	}
	footer .hint {
		margin: 0;
	}
	code {
		color: #bbb;
	}
	.buttons {
		display: flex;
		gap: 0.4rem;
	}
	button {
		padding: 0.45rem 0.8rem;
		border: 1px solid #444;
		border-radius: 5px;
		background: #222;
		color: inherit;
		font: inherit;
		cursor: pointer;
	}
	button:disabled {
		opacity: 0.4;
		cursor: default;
	}
	.primary {
		flex: 1;
		background: #1f3dff;
		border-color: #1f3dff;
		color: #fff;
	}
	.close {
		padding: 0 0.5rem;
		border: 0;
		background: none;
		font-size: 22px;
		line-height: 1;
	}
</style>

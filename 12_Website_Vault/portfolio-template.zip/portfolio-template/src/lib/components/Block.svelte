<!--
	DE: Wählt passend zum Typ des Blocks die richtige Darstellung.
	    Neuer Blocktyp? Komponente in blocks/ anlegen und hier eintragen.
	EN: Picks the right display for the block's type.
	    New block type? Create a component in blocks/ and register it here.
-->
<script>
	import Text from './blocks/Text.svelte';
	import Picture from './blocks/Picture.svelte';
	import Gallery from './blocks/Gallery.svelte';
	import Audio from './blocks/Audio.svelte';
	import Video from './blocks/Video.svelte';
	import File from './blocks/File.svelte';
	import Embed from './blocks/Embed.svelte';
	import Meta from './blocks/Meta.svelte';
	import Title from './blocks/Title.svelte';
	import WorkTile from './blocks/WorkTile.svelte';
	import Missing from './blocks/Missing.svelte';

	let { block, lang, consent, eager = false } = $props();
</script>

{#if block.type === 'text'}
	<Text html={block.html} />
{:else if block.type === 'image'}
	<Picture media={block.media} caption={block.caption} {eager} />
{:else if block.type === 'gallery'}
	<Gallery items={block.items} caption={block.caption} />
{:else if block.type === 'audio'}
	<Audio media={block.media} caption={block.caption} />
{:else if block.type === 'video'}
	<Video media={block.media} caption={block.caption} />
{:else if block.type === 'pdf' || block.type === 'file'}
	<File media={block.media} caption={block.caption} {lang} />
{:else if block.type === 'embed'}
	<Embed embed={block.embed} caption={block.caption} {lang} {consent} />
{:else if block.type === 'meta'}
	<Meta data={block.data} {lang} />
{:else if block.type === 'title'}
	<Title title={block.data.title} />
{:else if block.type === 'work'}
	<WorkTile work={block.data} {eager} />
{:else if block.type === 'missing'}
	<Missing name={block.name} />
{/if}

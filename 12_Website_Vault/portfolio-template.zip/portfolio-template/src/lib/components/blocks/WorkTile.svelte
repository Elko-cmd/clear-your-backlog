<!--
	DE: Kachel auf der Werkübersicht. Aussehen: .tile in theme.css
	EN: Tile on the works overview. Look: .tile in theme.css
-->
<script>
	import Picture from './Picture.svelte';

	let { work, eager = false } = $props();
</script>

<a class="tile" href={work.url}>
	{#if work.cover}
		<div class="cover">
			<Picture media={work.cover} sizes="(min-width: 760px) 33vw, 100vw" {eager} />
		</div>
	{/if}
	<span class="caption">
		<span class="tile-title">{work.title}</span>
		{#if work.year || work.kind}
			<span class="tile-info">{[work.year, work.kind].filter(Boolean).join(', ')}</span>
		{/if}
	</span>
</a>

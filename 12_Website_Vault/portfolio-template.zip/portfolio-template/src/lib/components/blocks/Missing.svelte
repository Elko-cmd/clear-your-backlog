<!--
	DE: Erscheint nur beim Entwickeln, wenn eine Datei nicht gefunden wurde.
	EN: Only appears during development when a file was not found.
-->
<script>
	import { dev } from '$app/env';

	let { name } = $props();
</script>

{#if dev}
	<p class="missing">
		<strong>Datei nicht gefunden / file not found:</strong>
		<code>{name}</code><br />
		<small>Liegt die Datei im Vault-Ordner? Stimmt der Name (Groß-/Kleinschreibung)? / Is the file inside the vault folder? Is the name spelled correctly?</small>
	</p>
{/if}

<style>
	.missing {
		padding: 1rem;
		border: 2px dashed #d33;
		color: #a00;
		background: #fff3f3;
	}
</style>

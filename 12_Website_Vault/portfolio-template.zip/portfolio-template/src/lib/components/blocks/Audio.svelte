<!-- DE: Eine Audiodatei aus dem Vault. / EN: An audio file from the vault. -->
<script>
	let { media, caption = undefined } = $props();
</script>

<figure>
	<audio controls preload="metadata" src={media.src}></audio>
	<figcaption>{caption ?? media.name}</figcaption>
</figure>

<style>
	audio {
		width: 100%;
	}
</style>

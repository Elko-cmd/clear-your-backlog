<!--
	DE: Titel und Werkangaben aus dem Frontmatter (Jahr, Material, Maße …).
	EN: Title and work details from the frontmatter (year, materials, dimensions …).
-->
<script>
	import { t } from '#lib/i18n.js';

	let { data, lang } = $props();

	const rows = $derived(
		[
			['kind', data.kind],
			['year', data.year],
			['materials', data.materials],
			['dimensions', data.dimensions],
			['duration', data.duration]
		]
			.filter(([, v]) => v)
			.map(([k, v]) => ({ label: t(lang, /** @type {any} */ (k)), value: v }))
			.concat(data.details ?? [])
	);
</script>

<header class="meta">
	<h1>{data.title}</h1>
	{#if rows.length || data.venues?.length}
		<dl>
			{#each rows as row (row.label)}
				<div>
					<dt>{row.label}</dt>
					<dd>{row.value}</dd>
				</div>
			{/each}
			{#if data.venues?.length}
				<div>
					<dt>{t(lang, 'venues')}</dt>
					<dd>
						{#each data.venues as venue, i (i)}<span>{venue}</span>{/each}
					</dd>
				</div>
			{/if}
		</dl>
	{/if}
</header>

<style>
	dl {
		margin: 0;
		font-size: var(--text-small);
	}
	dl > div {
		display: grid;
		grid-template-columns: 7.5em 1fr;
		gap: 1em;
		padding-block: 0.4em;
		border-top: 1px solid var(--color-lines);
	}
	dt {
		color: var(--color-muted);
	}
	dd {
		margin: 0;
	}
	dd span {
		display: block;
	}
</style>

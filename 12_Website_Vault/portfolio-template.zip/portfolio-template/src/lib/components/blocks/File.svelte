<!-- DE: PDF oder andere Datei als Link. / EN: PDF or other file as a link. -->
<script>
	import { t } from '#lib/i18n.js';

	let { media, caption = undefined, lang } = $props();
</script>

<a class="file" href={media.src} target="_blank" rel="noopener" download={media.kind === 'pdf' ? undefined : media.name}>
	<span class="label">{caption ?? media.name}</span>
	<span class="action">{media.kind === 'pdf' ? t(lang, 'openPdf') : t(lang, 'download')} ↗</span>
</a>

<style>
	.file {
		display: flex;
		justify-content: space-between;
		gap: 1rem;
		padding: 0.9rem 1rem;
		border: 1px solid var(--color-lines);
		text-decoration: none;
	}
	.file:hover {
		border-color: var(--color-accent);
	}
	.action {
		color: var(--color-muted);
		white-space: nowrap;
	}
</style>

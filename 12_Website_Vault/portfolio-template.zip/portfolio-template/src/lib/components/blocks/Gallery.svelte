<!--
	DE: Mehrere Bilder nebeneinander. Klick auf ein Bild öffnet es groß.
	EN: Several images side by side. Clicking an image opens it large.
-->
<script>
	import Picture from './Picture.svelte';

	let { items, caption = undefined } = $props();

	/** @type {HTMLDialogElement | undefined} */
	let dialog = $state();
	let current = $state(0);

	/** @param {number} i */
	function open(i) {
		current = i;
		dialog?.showModal();
	}

	/** @param {number} step */
	function go(step) {
		current = (current + step + items.length) % items.length;
	}

	/** @param {KeyboardEvent} e */
	function onkeydown(e) {
		if (e.key === 'ArrowRight') go(1);
		if (e.key === 'ArrowLeft') go(-1);
	}
</script>

<figure class="gallery">
	<ul style:--count={Math.min(items.length, 3)}>
		{#each items as item, i (i)}
			<li>
				<button type="button" onclick={() => open(i)} aria-label={item.caption ?? `${i + 1} / ${items.length}`}>
					<Picture media={item.media} sizes="(min-width: 760px) 33vw, 100vw" />
				</button>
			</li>
		{/each}
	</ul>
	{#if caption}<figcaption>{caption}</figcaption>{/if}
</figure>

<dialog bind:this={dialog} {onkeydown} onclick={(e) => e.target === dialog && dialog?.close()}>
	{#if items[current]}
		<Picture media={items[current].media} caption={items[current].caption} sizes="100vw" eager />
	{/if}
	<div class="controls">
		{#if items.length > 1}
			<button type="button" onclick={() => go(-1)} aria-label="←">←</button>
			<span>{current + 1} / {items.length}</span>
			<button type="button" onclick={() => go(1)} aria-label="→">→</button>
		{/if}
		<button type="button" onclick={() => dialog?.close()} aria-label="×">×</button>
	</div>
</dialog>

<style>
	ul {
		display: grid;
		grid-template-columns: repeat(var(--count), minmax(0, 1fr));
		gap: var(--grid-gap-x);
		margin: 0;
		padding: 0;
		list-style: none;
	}
	@media (max-width: 759px) {
		ul {
			grid-template-columns: 1fr 1fr;
		}
	}
	button {
		all: unset;
		cursor: zoom-in;
		display: block;
	}
	button:focus-visible {
		outline: 2px solid var(--color-accent);
	}
	dialog {
		max-width: none;
		max-height: none;
		width: 100vw;
		height: 100dvh;
		margin: 0;
		padding: var(--page-margin);
		border: 0;
		background: var(--color-background);
		color: var(--color-text);
	}
	dialog[open] {
		display: grid;
		grid-template-rows: 1fr auto;
		place-items: center;
	}
	dialog :global(figure) {
		display: grid;
		max-height: 100%;
		min-height: 0;
	}
	dialog :global(img) {
		max-height: calc(100dvh - 8rem);
		width: auto;
		object-fit: contain;
	}
	.controls {
		display: flex;
		gap: 1.5rem;
		align-items: center;
	}
	.controls button {
		cursor: pointer;
		font-size: 1.5rem;
		line-height: 1;
		padding: 0.25rem 0.5rem;
	}
</style>

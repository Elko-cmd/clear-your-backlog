<!--
	DE: Einbettung (YouTube, Vimeo, Bandcamp …) mit Zwei-Klick-Lösung:
	    Zuerst wird nur ein lokales Vorschaubild gezeigt. Erst nach einem Klick
	    lädt der fremde Player – vorher fließen keine Daten an den Anbieter.
	    Abschalten: `zwei_klick: false` in Einstellungen.md.
	EN: Embed (YouTube, Vimeo, Bandcamp …) with a two-click solution:
	    At first only a local preview image is shown. Only after a click does the
	    third-party player load – no data goes to the provider before that.
	    Turn off: `consent: false` in Einstellungen.md.
-->
<script>
	import { onMount } from 'svelte';
	import { t } from '#lib/i18n.js';

	let { embed, caption = undefined, lang, consent = true } = $props();

	const KEY = 'portfolio-embeds-allowed';
	let loaded = $state(false);
	let remember = $state(false);

	// DE: Ohne Zwei-Klick soll nichts automatisch losspielen.
	// EN: Without two-click nothing should start playing automatically.
	const src = $derived(consent ? embed.src : embed.src.replace(/([?&])(autoplay=1|auto_play=true)&?/, '$1').replace(/[?&]$/, ''));
	const shape = $derived(embed.height ? `height: ${embed.height}px` : `aspect-ratio: ${embed.aspect ?? '16 / 9'}`);

	onMount(() => {
		if (!consent) return void (loaded = true);
		try {
			const allowed = JSON.parse(localStorage.getItem(KEY) ?? '[]');
			if (allowed.includes(embed.provider)) loaded = true;
		} catch {
			// DE: Speicher nicht verfügbar – dann eben jedes Mal fragen.
			// EN: Storage not available – then just ask every time.
		}
	});

	function load() {
		loaded = true;
		if (!remember) return;
		try {
			const allowed = JSON.parse(localStorage.getItem(KEY) ?? '[]');
			localStorage.setItem(KEY, JSON.stringify([...new Set([...allowed, embed.provider])]));
		} catch {
			/* egal / never mind */
		}
	}
</script>

<figure class="embed">
	<div class="frame" style={shape}>
		{#if loaded}
			<iframe
				src={src}
				title={embed.title ?? caption ?? embed.label}
				allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
				allowfullscreen
				loading="lazy"
			></iframe>
		{:else}
			<div class="placeholder" class:small={embed.height && embed.height < 200}>
				{#if embed.thumb}
					<img src={embed.thumb.src} srcset={embed.thumb.srcset} sizes="(min-width: 760px) 66vw, 100vw" alt="" loading="lazy" />
				{/if}
				<div class="notice">
					<button type="button" onclick={load}>
						<span aria-hidden="true">▶</span>
						{t(lang, 'load')}
						<span class="provider">{embed.label}</span>
					</button>
					<p>
						{t(lang, 'consent', { provider: embed.label })}
						<label><input type="checkbox" bind:checked={remember} /> {t(lang, 'always', { provider: embed.label })}</label>
					</p>
				</div>
			</div>
		{/if}
	</div>
	{#if caption}<figcaption>{caption}</figcaption>{/if}
</figure>

<style>
	.frame {
		position: relative;
		width: 100%;
		background: var(--color-surface);
	}
	iframe,
	.placeholder {
		position: absolute;
		inset: 0;
		width: 100%;
		height: 100%;
		border: 0;
	}
	.placeholder {
		display: grid;
		place-items: center;
		overflow: hidden;
	}
	.placeholder img {
		position: absolute;
		inset: 0;
		width: 100%;
		height: 100%;
		object-fit: cover;
		filter: grayscale(0.3) brightness(0.85);
	}
	.notice {
		position: relative;
		display: grid;
		justify-items: center;
		gap: 0.6rem;
		padding: 1rem;
		max-width: 28rem;
		text-align: center;
		font-size: var(--text-small);
	}
	.placeholder:has(img) .notice {
		color: #fff;
		text-shadow: 0 1px 6px rgb(0 0 0 / 0.6);
	}
	.notice p {
		margin: 0;
	}
	.notice label {
		display: block;
		margin-top: 0.3rem;
		cursor: pointer;
	}
	button {
		display: inline-flex;
		gap: 0.5em;
		align-items: baseline;
		padding: 0.6em 1.1em;
		border: 0;
		background: var(--color-background);
		color: var(--color-text);
		font: inherit;
		font-size: var(--text-base);
		cursor: pointer;
		text-shadow: none;
	}
	button:hover {
		background: var(--color-accent);
		color: var(--color-background);
	}
	.provider {
		opacity: 0.6;
	}
	.small .notice {
		grid-auto-flow: column;
		align-items: center;
		max-width: none;
		text-align: left;
	}
	.small .notice p {
		max-width: 22rem;
	}
</style>

<!--
	DE: Ein Bild. Der Browser wählt aus `srcset` selbst die passende Größe.
	EN: An image. The browser picks the right size from `srcset` by itself.
-->
<script>
	let { media, caption = undefined, eager = false, sizes = '(min-width: 760px) 66vw, 100vw' } = $props();
</script>

<figure>
	<img
		src={media.src}
		srcset={media.srcset}
		{sizes}
		width={media.width}
		height={media.height}
		alt={caption ?? ''}
		loading={eager ? 'eager' : 'lazy'}
		decoding="async"
	/>
	{#if caption}<figcaption>{caption}</figcaption>{/if}
</figure>

<style>
	img {
		width: 100%;
		height: auto;
		background: var(--color-surface);
	}
</style>

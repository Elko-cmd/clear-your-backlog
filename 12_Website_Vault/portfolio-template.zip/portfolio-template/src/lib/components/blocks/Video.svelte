<!--
	DE: Eine Videodatei aus dem Vault. Tipp: Lange Videos besser auf Vimeo/YouTube
	    hochladen und den Link einfügen – das hält das Repository klein.
	EN: A video file from the vault. Tip: better upload long videos to Vimeo/YouTube
	    and insert the link – that keeps the repository small.
-->
<script>
	let { media, caption = undefined } = $props();
</script>

<figure>
	<!-- svelte-ignore a11y_media_has_caption -->
	<video controls playsinline preload="metadata" src={media.src}></video>
	{#if caption}<figcaption>{caption}</figcaption>{/if}
</figure>

<style>
	video {
		width: 100%;
		height: auto;
		background: #000;
	}
</style>

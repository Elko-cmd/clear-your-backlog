<!-- DE: Ein Textabschnitt aus der Notiz. / EN: A text section from the note. -->
<script>
	let { html } = $props();
</script>

<div class="text">{@html html}</div>

<style>
	.text {
		max-width: var(--text-max-width);
	}
	.text :global(> :last-child) {
		margin-bottom: 0;
	}
	.text :global(img) {
		margin-block: 1rem;
	}
</style>

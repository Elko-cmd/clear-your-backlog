<!--
	DE: Gemeinsame Vorlage für alle Seiten: Seitentitel, Vorschau für soziale
	    Netzwerke, das Raster – und beim Entwickeln der Layout-Editor.
	EN: Shared template for all pages: page title, social media preview,
	    the grid – and during development the layout editor.
-->
<script>
	import Grid from './Grid.svelte';
	import { arrange } from '#lib/layout/arrange.js';

	/**
	 * DE: `grid={false}` = kein frei anordenbares Raster (z.B. Werkliste); dann zeigt
	 *     die Seite nur, was als `children` hineingegeben wird.
	 * EN: `grid={false}` = no freely arrangeable grid (e.g. works list); the page
	 *     then only shows what is passed in as `children`.
	 * @type {{ data: any, grid?: boolean, children?: import('svelte').Snippet }}
	 */
	let { data, grid = true, children } = $props();

	const page = $derived(data.page);
	const site = $derived(data.settings?.title ?? '');
	const fullTitle = $derived(page.kind === 'home' ? site : `${page.title} – ${site}`);

	// DE: Position jedes Blocks (Spalte, Breite, Zeile, Höhe).
	// EN: Position of every block (column, width, row, height).
	// svelte-ignore state_referenced_locally
	let placements = $state(arrange(data.page.blocks, data.page.layout, data.columns));
	let editing = $state(false);
	/** @type {HTMLElement | undefined} */
	let gridElement = $state();

	// DE: Bei jedem Seitenwechsel neu anordnen. / EN: Re-arrange on every page change.
	$effect.pre(() => {
		placements = arrange(page.blocks, page.layout, data.columns);
	});

	// DE: Der Editor wird nur beim Entwickeln geladen – auf der fertigen Website nie.
	// EN: The editor is only loaded during development – never on the finished website.
	/** @type {any} */
	let Editor = $state(null);
	if (import.meta.env.DEV) import('#lib/dev/Editor.svelte').then((m) => (Editor = m.default));
</script>

<svelte:head>
	<title>{fullTitle}</title>
	{#if page.description ?? data.settings?.description}
		<meta name="description" content={page.description ?? data.settings.description} />
		<meta property="og:description" content={page.description ?? data.settings.description} />
	{/if}
	<meta property="og:title" content={fullTitle} />
	{#if page.cover}<meta property="og:image" content={page.cover.src} />{/if}
	{#each Object.entries(page.alternates ?? {}) as [lang, url] (lang)}
		<link rel="alternate" hreflang={lang} href={url} />
	{/each}
</svelte:head>

{#if grid}
	<Grid
		blocks={page.blocks}
		{placements}
		columns={data.columns}
		kind={page.kind}
		lang={data.lang}
		consent={data.settings?.consent ?? true}
		{editing}
		bind:element={gridElement}
	/>
{/if}

{@render children?.()}

{#if Editor && data.dev}
	<Editor
		{page}
		info={data.dev}
		lang={data.lang}
		columns={data.columns}
		grid={gridElement}
		canLayout={grid}
		design={data.design}
		bind:placements
		bind:editing
	/>
{/if}

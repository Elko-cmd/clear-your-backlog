<!--
	DE: Das Raster. Jeder Block sitzt in einer Zelle, deren Position aus dem
	    Layout kommt (Spalte, Breite, Zeile, Höhe). Auf schmalen Bildschirmen
	    stehen alle Blöcke einfach untereinander – in der Reihenfolge der Notiz.
	EN: The grid. Every block sits in a cell whose position comes from the
	    layout (column, width, row, height). On narrow screens all blocks are
	    simply stacked – in the order of the note.
-->
<script>
	import Block from './Block.svelte';

	/**
	 * @type {{
	 *   blocks: any[],
	 *   placements: Record<string, import('#lib/layout/arrange.js').Placement>,
	 *   columns: number,
	 *   lang: string,
	 *   consent: boolean,
 *   kind?: string,
	 *   editing?: boolean,
	 *   element?: HTMLElement
	 * }}
	 */
	let { blocks, placements, columns, lang, consent, kind = '', editing = false, element = $bindable() } = $props();

	const lastRow = $derived(Math.max(0, ...Object.values(placements).map((p) => p.row + p.rows - 1)));
</script>

<div class="grid" class:editing data-seite={kind} style:--columns={columns} bind:this={element}>
	{#each blocks as block, index (block.id)}
		{@const p = placements[block.id]}
		<div
			class="cell cell-{block.type}"
			data-id={block.id}
			style:--col={p?.col}
			style:--span={p?.span}
			style:--row={p?.row}
			style:--rows={p?.rows}
			style:--i={index}
			style:z-index={index + 1}
		>
			<Block {block} {lang} {consent} eager={index < 2} />
		</div>
	{/each}

	{#if editing}
		<!-- DE: Leere Zeilen unten, damit man Blöcke dorthin ziehen kann.
		     EN: Empty rows at the bottom so blocks can be dragged there. -->
		<div class="spacer" style:grid-row="{lastRow + 1} / span 2" aria-hidden="true"></div>
	{/if}
</div>

<style>
	.grid {
		position: relative;
		display: grid;
		grid-template-columns: minmax(0, 1fr);
		gap: var(--grid-gap-y) var(--grid-gap-x);
		align-items: start;
	}

	.cell {
		min-width: 0;
	}

	.spacer {
		grid-column: 1 / -1;
		min-height: 8rem;
	}

	/* DE: Ab dieser Breite gilt das gespeicherte Layout. / EN: From this width on, the stored layout applies. */
	@media (min-width: 760px) {
		.grid {
			grid-template-columns: repeat(var(--columns), minmax(0, 1fr));
		}
		.cell {
			grid-column: var(--col) / span var(--span);
			grid-row: var(--row) / span var(--rows);
		}
		.editing {
			grid-auto-rows: minmax(3rem, auto);
		}
	}
</style>

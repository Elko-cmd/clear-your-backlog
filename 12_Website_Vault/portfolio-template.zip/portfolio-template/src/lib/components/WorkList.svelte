<!--
	DE: Werkübersicht als Liste. „liste“: große Titel, das Titelbild folgt beim
	    Darüberfahren dem Mauszeiger. „index“: kompakte Tabelle mit kleinen Bildern.
	    Aussehen: .work-list / .work-index / .hover-preview in theme.css
	EN: Works overview as a list. "list": large titles, the cover image follows
	    the pointer on hover. "index": compact table with small images.
	    Look: .work-list / .work-index / .hover-preview in theme.css
-->
<script>
	/** @type {{ works: Array<{ title: string, url: string, cover?: any, year?: string, kind?: string }>, mode: 'liste' | 'index' }} */
	let { works, mode } = $props();

	/** @type {any} */
	let active = $state(null);
	let x = $state(0);
	let y = $state(0);

	/** @param {PointerEvent} e */
	function follow(e) {
		x = e.clientX;
		y = e.clientY;
	}
</script>

{#if mode === 'liste'}
	<ul class="work-list" onpointermove={follow} onpointerleave={() => (active = null)}>
		{#each works as work, i (work.url)}
			<li style:--i={i}>
				<a href={work.url} onpointerenter={() => (active = work.cover)} onfocus={() => (active = null)}>
					<span class="title">{work.title}</span>
					<span class="meta kind">{work.kind ?? ''}</span>
					<span class="meta year">{work.year ?? ''}</span>
				</a>
			</li>
		{/each}
	</ul>

	<div
		class="hover-preview"
		class:visible={active}
		style:transform="translate({x + 24}px, {Math.max(16, y - 120)}px)"
		aria-hidden="true"
	>
		{#if active}<img src={active.src} srcset={active.srcset} sizes="28vw" alt="" />{/if}
	</div>
{:else}
	<ul class="work-index">
		{#each works as work, i (work.url)}
			<li style:--i={i}>
				<a href={work.url}>
					{#if work.cover}
						<img src={work.cover.src} srcset={work.cover.srcset} sizes="5rem" alt="" loading="lazy" />
					{:else}
						<span></span>
					{/if}
					<span class="title">{work.title}</span>
					<span class="meta kind">{work.kind ?? ''}</span>
					<span class="meta year">{work.year ?? ''}</span>
				</a>
			</li>
		{/each}
	</ul>
{/if}

# Portfolio aus Obsidian

**[English version → README.en.md](README.en.md)**

Eine Vorlage für eine eigene Portfolio-Website. Du schreibst deine Texte in **Obsidian**, ordnest Bilder, Videos und Texte im **Browser** per Maus an, und **GitHub** veröffentlicht die Seite kostenlos im Netz.

Du brauchst dafür **keine Programmierkenntnisse und kein Terminal**. Alles funktioniert über Doppelklicks und normale Programme.

```
Obsidian (Texte, Bilder)  ──►  Vorschau im Browser (Layout anordnen)  ──►  GitHub Desktop (veröffentlichen)
```

**Was die Website kann:**
- Startseite, Werkübersicht, eine Seite pro Werk, CV und beliebige weitere Seiten (Kontakt, Impressum …)
- Bilder in mehreren Größen (schnell auf dem Handy), Galerien mit Großansicht
- Audio, Video und PDFs direkt aus dem Vault
- Einbettungen von YouTube, Vimeo, Bandcamp, SoundCloud, Spotify, Mixcloud und dem Internet Archive, datenschutzfreundlich per Zwei-Klick-Lösung
- Ein Layout-Editor: Blöcke auf einem Raster verschieben und in der Größe ändern, für jede Seite einzeln
- Ein Gestaltungs-Panel mit sieben Stilvorlagen, freien Farben, 18 Schriften (datenschutzfreundlich selbst gehostet), Schriftgrößen, Kopfzeilen- und Übersichtsvarianten
- Auf Wunsch zweisprachig (z.B. Deutsch und Englisch)

---

## Inhalt

1. [Was du brauchst](#1-was-du-brauchst)
2. [Einmalig einrichten](#2-einmalig-einrichten)
3. [Inhalte schreiben](#3-inhalte-schreiben)
4. [Layout anordnen](#4-layout-anordnen)
5. [Aussehen ändern](#5-aussehen-ändern)
6. [Veröffentlichen](#6-veröffentlichen)
7. [Wenn etwas nicht klappt](#7-wenn-etwas-nicht-klappt)
8. [Wie es funktioniert](#8-wie-es-funktioniert)
9. [Für Lehrende](#9-für-lehrende)

---

## 1. Was du brauchst

Installiere diese vier Programme. Alle sind kostenlos.

| Programm | Wofür | Download |
|---|---|---|
| **GitHub-Konto** | Speichert dein Projekt und veröffentlicht die Website | [github.com/signup](https://github.com/signup) |
| **GitHub Desktop** | Holt das Projekt auf deinen Computer und lädt Änderungen hoch | [desktop.github.com](https://desktop.github.com/) |
| **Node.js** (Version „LTS“) | Erzeugt die Vorschau der Website | [nodejs.org](https://nodejs.org/) |
| **Obsidian** | Hier schreibst du alle Texte | [obsidian.md](https://obsidian.md/) |

Bei Node.js lädst du die Version mit **„LTS“** herunter und installierst sie mit allen Standardeinstellungen. Danach musst du Node.js nie wieder öffnen, es arbeitet im Hintergrund.

---

## 2. Einmalig einrichten

### 2.1 Eigene Kopie auf GitHub anlegen

1. Öffne die Seite dieser Vorlage auf GitHub (den Link bekommst du im Seminar).
2. Klicke oben rechts auf den grünen Knopf **„Use this template“** und dann auf **„Create a new repository“**.
3. Gib einen Namen ein, z.B. `portfolio`. Wähle **Public** und klicke auf **„Create repository“**.

> **Tipp:** Wenn du dein Repository `deinname.github.io` nennst (mit deinem GitHub-Benutzernamen), ist die Website später direkt unter `https://deinname.github.io` erreichbar. Sonst liegt sie unter `https://deinname.github.io/portfolio/`.

### 2.2 Veröffentlichung einschalten

1. Klicke in deinem neuen Repository oben auf **Settings**.
2. Klicke links auf **Pages**.
3. Wähle bei **Source** den Eintrag **„GitHub Actions“**.

Das war's. Ab jetzt wird die Website bei jeder Änderung automatisch neu veröffentlicht.

### 2.3 Projekt auf den Computer holen

1. Öffne **GitHub Desktop** und melde dich mit deinem GitHub-Konto an.
2. Wähle **File → Clone repository …**, dann dein Repository, und klicke auf **Clone**.
3. Merk dir den Ordner, der unten bei **Local path** steht. Dort liegt jetzt dein Projekt.

### 2.4 Vorschau starten

Öffne den Projektordner (in GitHub Desktop: **Repository → Show in Finder / Show in Explorer**).

- **Mac:** Doppelklick auf **`Start (Mac).command`**
- **Windows:** Doppelklick auf **`Start (Windows).bat`**

Beim ersten Mal dauert es ein bis drei Minuten, weil Bausteine installiert werden. Danach öffnet sich der Browser mit deiner Website unter `http://localhost:5173`.

**Lass das schwarze Fenster offen**, solange du arbeitest. Schließt du es, endet die Vorschau.

> **Mac – „kann nicht geöffnet werden, da es von einem nicht verifizierten Entwickler stammt“:**
> Klicke die Datei mit **rechts** an, wähle **Öffnen** und bestätige mit **Öffnen**. Das ist nur beim ersten Mal nötig.
>
> **Windows – „Der Computer wurde durch Windows geschützt“:**
> Klicke auf **Weitere Informationen** und dann auf **Trotzdem ausführen**.

### 2.5 Obsidian einrichten

1. Öffne Obsidian und wähle **„Ordner als Vault öffnen“**.
2. Wähle im Projektordner den Unterordner **`inhalte`**. Wichtig: genau diesen Ordner, nicht den ganzen Projektordner.
3. Falls Obsidian fragt, ob du dem Vault vertraust, bestätige mit **„Vertrauen“**.
4. Empfohlen: **Einstellungen → Core-Plugins → Vorlagen** einschalten. Dann kannst du neue Werke mit einer fertigen Vorlage anlegen (Ordner `_Vorlagen`).

Ändere jetzt in Obsidian etwas in `Start.md` und speichere. Die Vorschau im Browser aktualisiert sich von selbst.

---

## 3. Inhalte schreiben

Alles, was auf der Website steht, liegt im Ordner `inhalte`. Eine ausführliche Anleitung mit allen Möglichkeiten findest du **direkt in Obsidian in der Notiz `LIESMICH`**.

```
inhalte/
├── Einstellungen.md        Name der Website, Navigation, Sprachen
├── Gestaltung.md           Farben, Schriften, Aufbau (oder im Browser einstellen)
├── Start.md                Text der Startseite
├── CV.md                   Lebenslauf
├── Werke/
│   └── Mein Werk/
│       ├── Mein Werk.md    Text und Angaben zum Werk
│       └── media/          Bilder, Audio, Video, PDFs des Werks
├── Seiten/                 Kontakt, Impressum, Datenschutz …
└── _Vorlagen/              Vorlagen (erscheinen nicht auf der Website)
```

**Die wichtigsten Regeln:**

- **Bild einfügen:** Bild in Obsidian in die Notiz ziehen. Bildunterschrift: `![[foto.jpg|Ausstellungsansicht, Foto: Name]]`
- **Mehrere Bilder direkt untereinander** (ohne Leerzeile) werden zu einer **Galerie**.
- **Video oder Musik von YouTube, Vimeo, Bandcamp …:** Den Link **allein in eine Zeile** schreiben.
- **Neuer Abschnitt:** Eine Überschrift `## …` oder eine Trennlinie `---` beginnt einen neuen Block, den du im Layout einzeln verschieben kannst.
- **Private Notizen:** Alles zwischen `%%` und `%%` erscheint nicht auf der Website.
- **Noch nicht veröffentlichen:** `veroeffentlichen: false` in die Eigenschaften eines Werks schreiben.
- **Ordner und Dateien, die mit `_` beginnen**, werden nie veröffentlicht.

---

## 4. Layout anordnen

Jede Seite besteht aus **Blöcken**: Titel und Angaben, Textabschnitte, Bilder, Galerien, Videos, Einbettungen. Wie die Blöcke angeordnet sind, legst du im Browser fest:

1. In der Vorschau erscheint unten eine schwarze Leiste. Klicke auf **„✎ Layout bearbeiten“**.
2. **Block ziehen** → verschieben. **Rand oder Ecke ziehen** → breiter, schmaler, höher.
3. Mit **Pfeiltasten** verschiebst du den ausgewählten Block, mit **Shift + Pfeiltasten** änderst du die Größe.
4. **„Zeile einfügen“** schafft Platz über dem ausgewählten Block.
5. Klicke auf **„Speichern“**.

Das Layout wird als Datei neben der Notiz gespeichert (z.B. `Mein Werk.layout.json`). Diese Datei enthält nur Positionen, keinen Text. Löschst du sie, ordnet die Website die Blöcke wieder automatisch an.

**Gut zu wissen:**
- Das Raster hat 12 Spalten. Blöcke dürfen sich überlappen.
- Neue Bilder oder Abschnitte, die noch keinen Platz im Layout haben, werden automatisch unten angehängt.
- Auf dem **Handy** stehen alle Blöcke einfach untereinander, in der Reihenfolge der Notiz.
- Die Leiste gibt es nur in der Vorschau. Auf der veröffentlichten Website ist sie nicht da.
- **„In Obsidian öffnen“** springt direkt zur passenden Notiz.

---

## 5. Aussehen ändern

**Im Browser:** Klicke in der Vorschau unten auf **„Aa Gestaltung“**. Rechts öffnet sich ein Panel. Jede Änderung ist sofort auf der Seite zu sehen:

- **Vorlagen:** sieben fertige Stile (White Cube, Galerie, Editorial, Brutal, Nacht, Signal, Studio) als Ausgangspunkt
- **Farben:** Hintergrund, Text, Akzent, Linien, Flächen, dazu ein automatischer Dunkelmodus
- **Schrift:** 18 freie Schriften für Text und Titel getrennt, auch eigene Schriftdateien; Schriftgröße, Titelgröße, Strichstärke, Laufweite, Versalien, Zeilenabstand, Linkstil
- **Aufbau:** Kopfzeile (Zeile, zentriert, großer Name, Seitenleiste), Abstände, Seitenbreite, runde Ecken, sanftes Einblenden
- **Werkübersicht:** freies Raster, große Liste mit Bildvorschau beim Darüberfahren oder kompakter Index; Kachelformat und Kacheltext

**„Speichern“** schreibt die Werte in `inhalte/Gestaltung.md`. Dort kannst du sie auch in Obsidian ändern. Alle Möglichkeiten stehen in der Notiz `LIESMICH` im Vault.

Die Schriften werden von deiner eigenen Website ausgeliefert, nicht von Google. Es fließen also keine Daten an Dritte. Veröffentlicht werden nur die zwei gewählten Schriften.

**Noch mehr Kontrolle:** Die Datei `src/lib/styles/theme.css` enthält das komplette Aussehen als gut kommentiertes CSS. Öffne sie mit einem Texteditor (z.B. [VS Code](https://code.visualstudio.com/)), ändere etwas und speichere. Die Vorschau zeigt die Änderung sofort.

---

## 6. Veröffentlichen

1. Öffne **GitHub Desktop**. Links siehst du alle geänderten Dateien.
2. Schreibe unten links bei **Summary** kurz, was du geändert hast, z.B. „Neues Werk“.
3. Klicke auf **„Commit to main“**.
4. Klicke oben auf **„Push origin“**.

Nach ein bis zwei Minuten ist die Website aktualisiert. Den Stand siehst du auf GitHub im Reiter **Actions**:

| Symbol | Bedeutung |
|---|---|
| 🟡 gelber Punkt | wird gerade gebaut |
| ✅ grüner Haken | veröffentlicht |
| ❌ rotes Kreuz | Fehler. Klicke darauf, öffne **build** und lies die rote Meldung. Dort steht, welche Datei das Problem hat. |

Die Adresse deiner Website steht unter **Settings → Pages**.

> **Eigene Domain** (z.B. `www.deinname.de`): Unter **Settings → Pages → Custom domain** eintragen und den Anweisungen von GitHub folgen.

---

## 7. Wenn etwas nicht klappt

**Die Vorschau zeigt „Hoppla / Oops“.**
Die Seite nennt die Datei und das Problem, z.B. eine falsch geschriebene Angabe. Korrigiere die Notiz in Obsidian und speichere. Die Seite lädt dann von selbst neu.

**Ein Bild erscheint nicht, stattdessen ein roter Kasten.**
Die Datei wurde nicht gefunden. Liegt sie im Ordner `inhalte`? Stimmt der Name genau, auch Groß- und Kleinschreibung?

**„Dieses Bild kann nicht gelesen werden“.**
Wahrscheinlich ein HEIC-Foto vom iPhone. Exportiere es als JPG.

**Das schwarze Fenster schließt sich sofort oder meldet „Node.js fehlt“.**
Installiere Node.js (Version LTS) von [nodejs.org](https://nodejs.org/) und starte den Computer neu.

**Die Vorschau startet, aber der Browser öffnet sich nicht.**
Öffne von Hand [http://localhost:5173](http://localhost:5173).

**Auf GitHub ist ein rotes Kreuz, aber die Vorschau funktioniert.**
Meist wurde eine Datei nicht mit hochgeladen. Prüfe in GitHub Desktop, ob links noch Dateien stehen, und veröffentliche sie.

**GitHub meldet, eine Datei sei zu groß.**
Dateien über 100 MB nimmt GitHub nicht an. Lade lange Videos auf Vimeo oder YouTube hoch und füge nur den Link ein.

**YouTube/Vimeo zeigt in der Vorschau kein Vorschaubild.**
Vorschaubilder werden beim Veröffentlichen heruntergeladen. Ohne Internetverbindung fehlen sie, die Einbettung funktioniert trotzdem.

---

## 8. Wie es funktioniert

Für alle, die verstehen oder verändern wollen, was unter der Haube passiert: **[docs/so-funktioniert-es.md](docs/so-funktioniert-es.md)**.

Kurz gesagt: [SvelteKit](https://svelte.dev/docs/kit) liest beim Bauen den Ordner `inhalte`, macht aus jeder Notiz eine Liste von Blöcken, legt das gespeicherte Layout darüber und schreibt fertige HTML-Seiten. Die Website braucht keinen Server und keine Datenbank.

---

## 9. Für Lehrende

- **Als Vorlage freigeben:** Im eigenen Repository unter **Settings → General** den Haken bei **„Template repository“** setzen. Dann erscheint für alle der Knopf „Use this template“.
- **Voraussetzungen:** Node.js 22.17 oder neuer, SvelteKit 3, Svelte 5. Die Abhängigkeiten sind bewusst wenige: unified/remark für Markdown, gray-matter, zod, sharp und die Schriftpakete von [Fontsource](https://fontsource.org/).
- **Beispielinhalte:** Der Ordner `inhalte` enthält eine fiktive Person „Alex Beispiel“ mit Bildern, Audio, Video, PDF und Einbettungen. Die Videos sind Beispielfilme der Blender Foundation (CC BY). Alle anderen Medien wurden für die Vorlage generiert und sind frei verwendbar.
- **Ideen für Übungen:** neuen Blocktyp anlegen (`src/lib/components/blocks/`), neuen Einbettungsdienst ergänzen (`src/lib/server/content/embeds.js`), eigene Stilvorlage oder neue Gestaltungsoption in `src/lib/design.js` anlegen (das Panel zeigt sie automatisch an), eigene Effekte in `theme.css`.

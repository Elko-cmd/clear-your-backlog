import { sveltekit } from '@sveltejs/kit/vite';
import adapter from '@sveltejs/adapter-static';
import { defineConfig } from 'vite';
import { vault } from './vite/vault-plugin.js';

export default defineConfig({
	plugins: [
		vault(),
		sveltekit({
			// DE: Baut eine rein statische Website (nur HTML, CSS, Bilder) in den Ordner `build/`.
			// EN: Builds a fully static website (only HTML, CSS, images) into the `build/` folder.
			adapter: adapter({ fallback: '404.html' }),

			paths: {
				// DE: Auf GitHub Pages liegt die Seite unter /<repository-name>.
				//     Das setzt der Workflow in .github/workflows/deploy.yml automatisch.
				// EN: On GitHub Pages the site lives under /<repository-name>.
				//     The workflow in .github/workflows/deploy.yml sets this automatically.
				base: /** @type {'' | `/${string}`} */ (process.env.BASE_PATH ?? ''),
				relative: false
			},

			prerender: {
				// DE: Kaputte Links brechen den Build nicht ab, sondern erzeugen eine Warnung.
				// EN: Broken links don't stop the build, they produce a warning instead.
				handleHttpError: 'warn',
				handleMissingId: 'ignore'
			}
		})
	],
	server: {
		fs: { allow: ['.'] }
	}
});

// ─────────────────────────────────────────────────────────────────────────────
// DE: Vite-Plugin, das NUR beim Entwickeln (`npm run dev`) aktiv ist.
//     1. Lädt die Seite im Browser neu, sobald du in Obsidian etwas änderst.
//     2. Nimmt Layouts aus dem Layout-Editor entgegen und speichert sie als
//        `.layout.json` neben der jeweiligen Notiz im Vault.
//     Im fertigen Build existiert nichts davon – die Website bleibt rein statisch.
//
// EN: Vite plugin that is ONLY active during development (`npm run dev`).
//     1. Reloads the page in the browser as soon as you change something in Obsidian.
//     2. Receives layouts from the layout editor and stores them as
//        `.layout.json` next to the corresponding note in the vault.
//     None of this exists in the final build – the website stays fully static.
// ─────────────────────────────────────────────────────────────────────────────

import fs from 'node:fs/promises';
import path from 'node:path';
import matter from 'gray-matter';
import config from '../portfolio.config.js';

export const LAYOUT_ENDPOINT = '/__portfolio/layout';
export const DESIGN_ENDPOINT = '/__portfolio/design';

/** @returns {import('vite').Plugin} */
export function vault() {
	const vaultDir = path.resolve(config.vault);

	return {
		name: 'portfolio-vault',
		apply: 'serve', // DE: nur im Dev-Server / EN: dev server only

		configureServer(server) {
			// ── 1. Live-Reload bei Änderungen im Vault / live reload on vault changes ──
			server.watcher.add(vaultDir);

			/** @type {ReturnType<typeof setTimeout> | undefined} */
			let timer;
			const onChange = (/** @type {string} */ file) => {
				if (!file.startsWith(vaultDir)) return;
				// DE: Signal an src/lib/server/content: „Vault neu einlesen“.
				// EN: Signal to src/lib/server/content: "re-read the vault".
				/** @type {any} */ (globalThis).__portfolioVaultVersion = Date.now();
				// DE: Layout-Dateien schreibt der Editor selbst – kein Neuladen nötig.
				// EN: Layout files are written by the editor itself – no reload needed.
				if (file.endsWith('.layout.json') || file.endsWith('.tmp')) return;
				if (file.includes(`${path.sep}.obsidian${path.sep}`)) return;

				clearTimeout(timer);
				timer = setTimeout(() => server.ws.send({ type: 'full-reload' }), 150);
			};
			server.watcher.on('change', onChange);
			server.watcher.on('add', onChange);
			server.watcher.on('unlink', onChange);

			// ── 3. Gestaltung speichern / save design ──
			// DE: Ersetzt nur die Eigenschaften (Frontmatter) von Gestaltung.md –
			//     der Text darunter bleibt erhalten.
			// EN: Only replaces the properties (frontmatter) of Gestaltung.md –
			//     the text below stays as it is.
			server.middlewares.use(DESIGN_ENDPOINT, async (req, res) => {
				res.setHeader('content-type', 'application/json');
				if (req.method !== 'POST') {
					res.statusCode = 405;
					return res.end();
				}
				try {
					const body = JSON.parse(await readBody(req));
					const target = path.join(vaultDir, config.files.design);
					let content = '';
					try {
						content = matter(await fs.readFile(target, 'utf8')).content;
					} catch {
						content = '\nDie Eigenschaften oben steuern das Aussehen der Website. Siehe [[LIESMICH]].\n';
					}
					const tmp = `${target}.tmp`;
					await fs.writeFile(tmp, matter.stringify(content, body.values ?? {}), 'utf8');
					await fs.rename(tmp, target);
					res.end(JSON.stringify({ ok: true, file: config.files.design }));
				} catch (error) {
					res.statusCode = 400;
					res.end(JSON.stringify({ ok: false, message: String(/** @type {Error} */ (error).message) }));
				}
			});

			// ── 2. Layout speichern / save layout ──
			server.middlewares.use(LAYOUT_ENDPOINT, async (req, res) => {
				if (req.method !== 'POST') {
					res.statusCode = 405;
					return res.end();
				}

				try {
					const body = JSON.parse(await readBody(req));
					const target = path.resolve(vaultDir, String(body.file ?? ''));

					// DE: Sicherheitsnetz – nur .layout.json-Dateien innerhalb des Vaults.
					// EN: Safety net – only .layout.json files inside the vault.
					if (!target.startsWith(vaultDir + path.sep) || !target.endsWith('.layout.json')) {
						throw new Error(`Ungültiger Pfad / invalid path: ${body.file}`);
					}

					const json = JSON.stringify(body.layout, null, '\t') + '\n';
					const tmp = `${target}.tmp`;
					await fs.mkdir(path.dirname(target), { recursive: true });
					await fs.writeFile(tmp, json, 'utf8');
					await fs.rename(tmp, target); // DE: atomar / EN: atomic
					/** @type {any} */ (globalThis).__portfolioVaultVersion = Date.now();

					res.setHeader('content-type', 'application/json');
					res.end(JSON.stringify({ ok: true, file: path.relative(vaultDir, target) }));
				} catch (error) {
					res.statusCode = 400;
					res.setHeader('content-type', 'application/json');
					res.end(JSON.stringify({ ok: false, message: String(/** @type {Error} */ (error).message) }));
				}
			});
		}
	};
}

/** @param {import('node:http').IncomingMessage} req */
function readBody(req) {
	return new Promise((resolve, reject) => {
		let data = '';
		req.on('data', (chunk) => {
			data += chunk;
			if (data.length > 1_000_000) reject(new Error('Body too large'));
		});
		req.on('end', () => resolve(data));
		req.on('error', reject);
	});
}

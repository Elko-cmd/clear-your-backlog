@echo off
rem -------------------------------------------------------------------------
rem DE: Doppelklick startet die Vorschau der Website im Browser.
rem     Beim ersten Mal werden die noetigen Bausteine installiert (1-3 Minuten).
rem     Zum Beenden: dieses Fenster schliessen.
rem EN: Double-click starts the website preview in your browser.
rem     The first time, the required building blocks are installed (1-3 minutes).
rem     To stop: close this window.
rem -------------------------------------------------------------------------
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo   Portfolio-Vorschau / portfolio preview
echo.
where node >nul 2>nul
if errorlevel 1 goto nonode
node -e "const [a,b]=process.versions.node.split(\".\").map(Number);process.exit(a>22||(a===22&&b>=17)?0:1)"
if errorlevel 1 goto nonode
if not exist node_modules (
  echo   Installiere Bausteine ... / installing building blocks ...
  call npm install --no-fund --no-audit
  if errorlevel 1 goto failed
)
echo.
echo   Gleich oeffnet sich der Browser. Dieses Fenster offen lassen!
echo   Your browser will open shortly. Keep this window open!
echo.
call npm run dev -- --open
pause
exit /b
:nonode
echo   Node.js (Version 22.17 oder neuer) fehlt. / Node.js (version 22.17 or newer) is missing.
echo   Bitte die LTS-Version von nodejs.org installieren und danach erneut doppelklicken.
echo   Please install the LTS version from nodejs.org and double-click again afterwards.
start "" "https://nodejs.org/"
pause
exit /b 1
:failed
echo   Fehler bei der Installation. / Installation failed.
pause
exit /b 1

// ─────────────────────────────────────────────────────────────────────────────
// DE: Technische Grundeinstellungen. Für Titel, Navigation, Farben usw. musst du
//     hier NICHTS ändern – das passiert in `inhalte/Einstellungen.md` in Obsidian.
// EN: Technical base settings. For title, navigation, colours etc. you do NOT
//     need to touch this file – use `inhalte/Einstellungen.md` in Obsidian.
// ─────────────────────────────────────────────────────────────────────────────

export default {
	// DE: Ordner mit dem Obsidian-Vault (relativ zu diesem Projektordner).
	// EN: Folder containing the Obsidian vault (relative to this project folder).
	vault: 'inhalte',

	// DE: Namen der Unterordner und Dateien im Vault.
	// EN: Names of sub-folders and files inside the vault.
	folders: {
		works: 'Werke',
		pages: 'Seiten'
	},
	files: {
		settings: 'Einstellungen.md',
		design: 'Gestaltung.md',
		home: 'Start.md',
		cv: 'CV.md',
		overviewLayout: 'Werke.layout.json'
	},

	// DE: Ordner und Dateien, die NIE auf der Website landen (beginnen mit `_` oder `.`).
	// EN: Folders and files that NEVER end up on the website (start with `_` or `.`).
	ignore: /(^|\/)[_.]/,

	// DE: Bildbreiten, die beim Bauen erzeugt werden (in Pixeln).
	// EN: Image widths generated during the build (in pixels).
	imageWidths: [480, 960, 1600, 2400],

	// DE: Breite des Rasters im Layout-Editor (Spalten).
	// EN: Width of the grid in the layout editor (columns).
	columns: 12
};

# How it works

**[Deutsch → so-funktioniert-es.md](so-funktioniert-es.md)**

This page explains what happens between "note in Obsidian" and "finished website". You don't need it to use the template, but it helps if you want to change something.

## The journey of a note

```
inhalte/Werke/My Work/My Work.md
        │
        │  1. read                src/lib/server/content/files.js
        ▼
   frontmatter + Markdown text
        │
        │  2. validate            src/lib/server/content/schema.js
        │  3. translate Obsidian  src/lib/server/content/markdown.js  (preprocess)
        │     syntax
        ▼
   syntax tree (mdast)
        │
        │  4. cut into blocks     src/lib/server/content/markdown.js  (toBlocks)
        │     register media      src/lib/server/content/media.js
        │     embeds              src/lib/server/content/embeds.js
        ▼
   [ meta, text-1, image:photo.jpg, gallery:…, embed:vimeo:123, … ]
        │
        │  5. combine with        src/lib/layout/arrange.js
        │     the layout          + My Work.layout.json
        ▼
   block → column, width, row, height
        │
        │  6. display             src/lib/components/Grid.svelte, Block.svelte, blocks/*
        ▼
   finished HTML page in build/werke/my-work/index.html
```

## The folders in the project

| Folder / file | Contents |
|---|---|
| `inhalte/` | The Obsidian vault, i.e. all content |
| `portfolio.config.js` | Technical base settings: folder names, image sizes, number of columns |
| `vite.config.js` | Build settings, including the address on GitHub Pages |
| `vite/vault-plugin.js` | Only active during development: live reload and saving layouts |
| `src/lib/server/content/` | Reads the vault and builds pages and blocks from it |
| `src/lib/layout/arrange.js` | Combines blocks with the stored layout |
| `src/lib/components/` | Display: grid, blocks, page template |
| `src/lib/dev/Editor.svelte` | The layout editor (only loaded in the preview) |
| `src/lib/design.js` | Design model: all options, presets, font list, conversion to CSS |
| `src/lib/server/content/fonts.js` | Fetches the chosen fonts from the Fontsource packages |
| `src/lib/dev/DesignPanel.svelte` | The design panel (preview only) |
| `src/lib/styles/theme.css` | The complete look as CSS |
| `src/lib/i18n.js` | Fixed labels like "Works", "Play" in several languages |
| `src/routes/` | The pages of the website, one file per page type |
| `.github/workflows/deploy.yml` | Building and publishing on GitHub |

## Blocks

A **block** is a piece of a page that can be placed individually in the layout. Every block has an **ID**, which the layout file uses to remember where it sits.

| Block | comes from | ID |
|---|---|---|
| Title & details | a work's frontmatter | `meta` |
| Title | title of a page or the CV | `title` |
| Text | paragraphs up to the next `#`/`##` heading or `---` | `text-1`, `text-2` … or your own ID with `^name` at the end of a paragraph |
| Image | a paragraph consisting of a single image | `image:filename.jpg` |
| Gallery | several images without an empty line between them, or `> [!gallery]` | `gallery:first-image.jpg` |
| Audio / video / PDF / file | `![[file.mp3]]` etc. | `audio:file.mp3` … |
| Embed | a link on a line of its own, or `> [!embed] Title` | `embed:youtube:abc123` |
| Work tile | every work on the overview page | `work:address` |

Because text IDs are numbered in order, a new section in the middle of a note can shift the numbers. To avoid that, give paragraphs a fixed ID with Obsidian's block identifier: `My paragraph. ^intro`.

## The layout file

```json
{
	"version": 1,
	"columns": 12,
	"blocks": {
		"meta":                 { "col": 1, "span": 4,  "row": 1, "rows": 1 },
		"text-1":               { "col": 6, "span": 7,  "row": 1, "rows": 1 },
		"image:photo-01.jpg":   { "col": 1, "span": 12, "row": 2, "rows": 1 }
	}
}
```

- `col`: start column (1–12), `span`: width in columns
- `row`: start row, `rows`: how many rows the block spans

Rows are as tall as their content (CSS grid with `auto` rows). The layout file applies to all language versions of a page. Blocks without an entry are appended at the bottom by `arrange.js`, each at its default width.

## Design

```
Gestaltung.md  ──►  resolveDesign()   preset + your values + defaults, with validation
                        │
                        ├─► toCss()          CSS variables (--color-…, --font-…, --text-title …)
                        ├─► toAttributes()   data attributes on <html> (data-kopfzeile="seitlich" …)
                        └─► buildFonts()     @font-face rules, font files to /medien/
                        ▼
                  theme.css uses the variables and attributes
```

All three functions live in `src/lib/design.js` and run on the server **and** in the browser. That's why the panel can show every change instantly: it puts the new values into `designState.preview` (`src/lib/design-state.svelte.js`), and `+layout.svelte` computes new CSS from them live.

During development the server provides all fonts so you can try them in the panel. The build only contains the two chosen ones, and of those only the Latin character sets.

Large titles adapt to the width of their block using the container query unit `cqi` (`.cell h1` in `theme.css`). That way they never run into the neighbouring block at any title size.

**New option:** add it to `OPTIONS` (the panel shows it automatically), implement it in `toCss()` or `toAttributes()` and use it in `theme.css`. **New preset:** add an entry to `PRESETS`. **New font:** add a package from [fontsource.org](https://fontsource.org/) with `npm install` and register it in `FONTS`.

## Preview and editor

`npm run dev` starts a local server (Vite), plus the plugin `vite/vault-plugin.js`:

1. It watches the `inhalte` folder. On every change it bumps a version number (so the vault is re-read) and reloads the browser.
2. It provides the addresses `/__portfolio/layout` and `/__portfolio/design`. When saving, the editor sends the layout there and the plugin writes it into the vault as `.layout.json`. It only ever writes files with this extension inside the vault. Via `/__portfolio/design` the panel saves only the differences from the preset into the properties of `Gestaltung.md`; the text below them is kept.

Neither the plugin nor the editor exist in the finished build.

## Building and publishing

`npm run build` uses `@sveltejs/adapter-static` to create a fully static website in the `build/` folder:

- Every page is **prerendered** (`prerender = true`). SvelteKit follows all links plus the `entries()` lists of works and pages.
- Media are produced by the route `src/routes/medien/[file]/+server.js`: images with [sharp](https://sharp.pixelplumbing.com/) in several widths as WebP, everything else copied unchanged. Intermediate results go into `.cache/`.
- Preview images from YouTube and Vimeo are downloaded during the build. That way viewing the page sends no data to these services before someone clicks "Play".

On GitHub, the workflow `.github/workflows/deploy.yml` does this. It sets `BASE_PATH` to the repository's name (e.g. `/portfolio`) so that all links under `name.github.io/portfolio/` are correct.

## Extending

**New embed service:** add an entry to `PROVIDERS` in `src/lib/server/content/embeds.js`. `match()` receives the link as a `URL` and returns the iframe address.

**New block type:**
1. Recognise it in `markdown.js` and output it as a block with its own `type` (e.g. via a callout `> [!quote]`).
2. Create a component in `src/lib/components/blocks/`.
3. Register it in `src/lib/components/Block.svelte`.

**New field for works:** add it to `workSchema` in `schema.js` (German name under `ALIASES`) and display it in `blocks/Meta.svelte`. For quick additions there is also `details:`, which shows any label/value pairs.

**Another language:** add it to `languages` in `Einstellungen.md`, put translations as `Note.en.md` next to the originals, and add the fixed labels in `src/lib/i18n.js`.

## Technology used

- [SvelteKit 3](https://svelte.dev/docs/kit) with [Svelte 5](https://svelte.dev/docs/svelte), [Vite](https://vite.dev/)
- [unified](https://unifiedjs.com/) / remark / rehype for Markdown
- [gray-matter](https://github.com/jonschlinkert/gray-matter) for frontmatter
- [zod](https://zod.dev/) to validate fields
- [sharp](https://sharp.pixelplumbing.com/) for images
- [Fontsource](https://fontsource.org/) for the fonts (SIL Open Font License)

# So funktioniert es

**[English → how-it-works.md](how-it-works.md)**

Diese Seite erklärt, was zwischen „Notiz in Obsidian“ und „fertige Website“ passiert. Du brauchst sie nicht, um die Vorlage zu benutzen. Sie hilft dir aber, wenn du etwas verändern willst.

## Der Weg einer Notiz

```
inhalte/Werke/Mein Werk/Mein Werk.md
        │
        │  1. einlesen            src/lib/server/content/files.js
        ▼
   Frontmatter + Markdown-Text
        │
        │  2. prüfen              src/lib/server/content/schema.js
        │  3. Obsidian-Syntax     src/lib/server/content/markdown.js  (preprocess)
        │     übersetzen
        ▼
   Syntaxbaum (mdast)
        │
        │  4. in Blöcke schneiden src/lib/server/content/markdown.js  (toBlocks)
        │     Medien anmelden     src/lib/server/content/media.js
        │     Einbettungen        src/lib/server/content/embeds.js
        ▼
   [ meta, text-1, image:foto.jpg, gallery:…, embed:vimeo:123, … ]
        │
        │  5. mit Layout          src/lib/layout/arrange.js
        │     zusammenführen      + Mein Werk.layout.json
        ▼
   Block → Spalte, Breite, Zeile, Höhe
        │
        │  6. anzeigen            src/lib/components/Grid.svelte, Block.svelte, blocks/*
        ▼
   fertige HTML-Seite in build/werke/mein-werk/index.html
```

## Die Ordner im Projekt

| Ordner / Datei | Inhalt |
|---|---|
| `inhalte/` | Der Obsidian-Vault, also alle Inhalte |
| `portfolio.config.js` | Technische Grundeinstellungen: Ordnernamen, Bildgrößen, Spaltenzahl |
| `vite.config.js` | Build-Einstellungen, u.a. die Adresse auf GitHub Pages |
| `vite/vault-plugin.js` | Nur beim Entwickeln aktiv: Live-Reload und Speichern der Layouts |
| `src/lib/server/content/` | Liest den Vault und baut daraus Seiten und Blöcke |
| `src/lib/layout/arrange.js` | Setzt Blöcke und gespeichertes Layout zusammen |
| `src/lib/components/` | Darstellung: Raster, Blöcke, Seitenvorlage |
| `src/lib/dev/Editor.svelte` | Der Layout-Editor (wird nur in der Vorschau geladen) |
| `src/lib/design.js` | Gestaltungsmodell: alle Optionen, Vorlagen, Schriftliste, Umwandlung in CSS |
| `src/lib/server/content/fonts.js` | Holt die gewählten Schriften aus den Fontsource-Paketen |
| `src/lib/dev/DesignPanel.svelte` | Das Gestaltungs-Panel (nur in der Vorschau) |
| `src/lib/styles/theme.css` | Das komplette Aussehen als CSS |
| `src/lib/i18n.js` | Feste Beschriftungen wie „Werke“, „Abspielen“ in mehreren Sprachen |
| `src/routes/` | Die Seiten der Website, eine Datei pro Seitentyp |
| `.github/workflows/deploy.yml` | Bauen und Veröffentlichen auf GitHub |

## Blöcke

Ein **Block** ist ein Stück Seite, das im Layout einzeln platziert werden kann. Jeder Block hat eine **ID**. Über sie merkt sich die Layout-Datei, wo er sitzt.

| Block | entsteht aus | ID |
|---|---|---|
| Titel & Angaben | Frontmatter eines Werks | `meta` |
| Titel | Titel einer Seite oder des CV | `title` |
| Text | Absätze bis zur nächsten `#`/`##`-Überschrift oder `---` | `text-1`, `text-2` … oder eigene ID mit `^name` am Absatzende |
| Bild | Absatz, der nur aus einem Bild besteht | `image:dateiname.jpg` |
| Galerie | mehrere Bilder ohne Leerzeile dazwischen, oder `> [!gallery]` | `gallery:erstes-bild.jpg` |
| Audio / Video / PDF / Datei | `![[datei.mp3]]` usw. | `audio:datei.mp3` … |
| Einbettung | Link allein in einer Zeile, oder `> [!embed] Titel` | `embed:youtube:abc123` |
| Werk-Kachel | jedes Werk auf der Übersichtsseite | `work:adresse` |

Weil Text-IDs nach Reihenfolge nummeriert werden, kann ein neuer Abschnitt mitten in der Notiz die Nummern verschieben. Wer das vermeiden will, gibt Absätzen eine feste ID mit Obsidians Block-Kennung: `Mein Absatz. ^einleitung`.

## Die Layout-Datei

```json
{
	"version": 1,
	"columns": 12,
	"blocks": {
		"meta":                 { "col": 1, "span": 4,  "row": 1, "rows": 1 },
		"text-1":               { "col": 6, "span": 7,  "row": 1, "rows": 1 },
		"image:foto-01.jpg":    { "col": 1, "span": 12, "row": 2, "rows": 1 }
	}
}
```

- `col`: Startspalte (1–12), `span`: Breite in Spalten
- `row`: Startzeile, `rows`: wie viele Zeilen der Block überspannt

Die Zeilen sind so hoch wie ihr Inhalt (CSS Grid mit `auto`-Zeilen). Die Layout-Datei gilt für alle Sprachfassungen einer Seite. Blöcke ohne Eintrag hängt `arrange.js` unten an, jeweils so breit wie ihre Standardbreite.

## Gestaltung

```
Gestaltung.md  ──►  resolveDesign()   Vorlage + eigene Angaben + Grundwerte, mit Prüfung
                        │
                        ├─► toCss()          CSS-Variablen (--color-…, --font-…, --text-title …)
                        ├─► toAttributes()   data-Attribute am <html> (data-kopfzeile="seitlich" …)
                        └─► buildFonts()     @font-face-Regeln, Schriftdateien nach /medien/
                        ▼
                  theme.css nutzt Variablen und Attribute
```

Alle drei Funktionen liegen in `src/lib/design.js` und laufen auf dem Server **und** im Browser. Darum kann das Panel jede Änderung sofort zeigen: Es legt die neuen Werte in `designState.preview` (`src/lib/design-state.svelte.js`), und `+layout.svelte` rechnet daraus live neues CSS.

Beim Entwickeln stellt der Server alle Schriften bereit, damit man sie im Panel ausprobieren kann. Im Build landen nur die zwei gewählten, und davon nur die lateinischen Zeichensätze.

Große Titel passen sich mit der Container-Query-Einheit `cqi` der Breite ihres Blocks an (`.cell h1` in `theme.css`). So ragen sie bei keiner Titelgröße in den Nachbarblock.

**Neue Option:** in `OPTIONS` eintragen (das Panel zeigt sie automatisch), in `toCss()` oder `toAttributes()` umsetzen und in `theme.css` verwenden. **Neue Vorlage:** Eintrag in `PRESETS`. **Neue Schrift:** Paket von [fontsource.org](https://fontsource.org/) mit `npm install` hinzufügen und in `FONTS` eintragen.

## Vorschau und Editor

`npm run dev` startet einen lokalen Server (Vite). Dazu kommt das Plugin `vite/vault-plugin.js`:

1. Es beobachtet den Ordner `inhalte`. Bei jeder Änderung setzt es eine Versionsnummer hoch (damit der Vault neu gelesen wird) und lädt den Browser neu.
2. Es stellt die Adressen `/__portfolio/layout` und `/__portfolio/design` bereit. Dorthin schickt der Editor beim Speichern das Layout, und das Plugin schreibt es als `.layout.json` in den Vault. Es schreibt ausschließlich Dateien mit dieser Endung innerhalb des Vaults. Das Panel speichert über `/__portfolio/design` nur die Abweichungen von der Vorlage in die Eigenschaften von `Gestaltung.md`; der Text darunter bleibt erhalten.

Im fertigen Build gibt es weder das Plugin noch den Editor.

## Bauen und Veröffentlichen

`npm run build` erzeugt mit `@sveltejs/adapter-static` eine rein statische Website im Ordner `build/`:

- Jede Seite wird **vorab gerendert** (`prerender = true`). SvelteKit folgt dabei allen Links und den `entries()`-Listen der Werke und Seiten.
- Medien werden über die Route `src/routes/medien/[file]/+server.js` erzeugt: Bilder mit [sharp](https://sharp.pixelplumbing.com/) in mehreren Breiten als WebP, alles andere unverändert kopiert. Zwischenergebnisse landen in `.cache/`.
- Vorschaubilder von YouTube und Vimeo werden beim Bauen heruntergeladen. So gehen beim Betrachten der Seite keine Daten an diese Dienste, bevor jemand auf „Abspielen“ klickt.

Auf GitHub erledigt das der Workflow `.github/workflows/deploy.yml`. Er setzt `BASE_PATH` auf den Namen des Repositorys (z.B. `/portfolio`), damit alle Links unter `name.github.io/portfolio/` stimmen.

## Erweitern

**Neuer Einbettungsdienst:** In `src/lib/server/content/embeds.js` einen Eintrag in `PROVIDERS` ergänzen. `match()` bekommt den Link als `URL` und gibt die iframe-Adresse zurück.

**Neuer Blocktyp:**
1. In `markdown.js` erkennen und als Block mit eigenem `type` ausgeben (z.B. über ein Callout `> [!zitat]`).
2. Eine Komponente in `src/lib/components/blocks/` anlegen.
3. Sie in `src/lib/components/Block.svelte` eintragen.

**Neue Angabe bei Werken:** In `schema.js` im `workSchema` ergänzen (deutscher Name bei `ALIASES`) und in `blocks/Meta.svelte` anzeigen. Für schnelle Ergänzungen gibt es auch `angaben:`, das beliebige Paare aus Bezeichnung und Wert anzeigt.

**Weitere Sprache:** In `Einstellungen.md` bei `sprachen` ergänzen, Übersetzungen als `Notiz.en.md` neben die Originale legen und in `src/lib/i18n.js` die festen Beschriftungen ergänzen.

## Verwendete Technik

- [SvelteKit 3](https://svelte.dev/docs/kit) mit [Svelte 5](https://svelte.dev/docs/svelte), [Vite](https://vite.dev/)
- [unified](https://unifiedjs.com/) / remark / rehype für Markdown
- [gray-matter](https://github.com/jonschlinkert/gray-matter) für das Frontmatter
- [zod](https://zod.dev/) zum Prüfen der Angaben
- [sharp](https://sharp.pixelplumbing.com/) für Bilder
- [Fontsource](https://fontsource.org/) für die Schriften (SIL Open Font License)

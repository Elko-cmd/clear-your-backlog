#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# DE: Doppelklick startet die Vorschau der Website im Browser.
#     Beim ersten Mal werden die nötigen Bausteine installiert (1–3 Minuten).
#     Zum Beenden: dieses Fenster schließen.
# EN: Double-click starts the website preview in your browser.
#     The first time, the required building blocks are installed (1–3 minutes).
#     To stop: close this window.
# ─────────────────────────────────────────────────────────────────────────────
cd "$(dirname "$0")" || exit 1
export PATH="/usr/local/bin:/opt/homebrew/bin:$HOME/.volta/bin:$PATH"

echo ""
echo "  Portfolio-Vorschau / portfolio preview"
echo "  ──────────────────────────────────────"

if ! command -v node >/dev/null 2>&1 || ! node -e "const [a,b]=process.versions.node.split('.').map(Number);process.exit(a>22||(a===22&&b>=17)?0:1)"; then
  echo ""
  echo "  Node.js (Version 22.17 oder neuer) fehlt."
  echo "  Node.js (version 22.17 or newer) is missing."
  echo ""
  echo "  → Bitte die LTS-Version von nodejs.org installieren und danach erneut doppelklicken."
  echo "  → Please install the LTS version from nodejs.org and double-click again afterwards."
  open "https://nodejs.org/"
  read -r -p "  [Enter] "
  exit 1
fi

if [ ! -d node_modules ] || [ package.json -nt node_modules/.package-lock.json ]; then
  echo ""
  echo "  Installiere Bausteine … / installing building blocks …"
  npm install --no-fund --no-audit || { read -r -p "  Fehler / error – [Enter] "; exit 1; }
fi

echo ""
echo "  Gleich öffnet sich der Browser. Dieses Fenster offen lassen!"
echo "  Your browser will open shortly. Keep this window open!"
echo ""
npm run dev -- --open

# Portfolio from Obsidian

**[Deutsche Version → README.md](README.md)**

A template for your own portfolio website. You write your texts in **Obsidian**, arrange images, videos and texts with the mouse **in the browser**, and **GitHub** publishes the site online for free.

You need **no programming knowledge and no terminal**. Everything works with double-clicks and ordinary apps.

```
Obsidian (texts, images)  ──►  browser preview (arrange layout)  ──►  GitHub Desktop (publish)
```

**What the website can do:**
- Home page, works overview, one page per work, CV and any number of further pages (contact, imprint …)
- Images in several sizes (fast on phones), galleries with a large view
- Audio, video and PDFs straight from the vault
- Embeds from YouTube, Vimeo, Bandcamp, SoundCloud, Spotify, Mixcloud and the Internet Archive, privacy-friendly with a two-click solution
- A layout editor: move and resize blocks on a grid, separately for every page
- A design panel with seven style presets, free colours, 18 fonts (privacy-friendly, self-hosted), font sizes, header and overview variants
- Optionally bilingual (e.g. German and English)

> **Note on names:** The template was made for a German seminar, so folder names and the example content are German (`inhalte` = content, `Werke` = works, `Seiten` = pages, `Einstellungen` = settings, `Gestaltung` = design). Every property can also be written in English (`title`, `year`, `languages` …). Folder names can be changed in `portfolio.config.js`.

---

## Contents

1. [What you need](#1-what-you-need)
2. [One-time setup](#2-one-time-setup)
3. [Writing content](#3-writing-content)
4. [Arranging the layout](#4-arranging-the-layout)
5. [Changing the look](#5-changing-the-look)
6. [Publishing](#6-publishing)
7. [When something doesn't work](#7-when-something-doesnt-work)
8. [How it works](#8-how-it-works)
9. [For instructors](#9-for-instructors)

---

## 1. What you need

Install these four things. All are free.

| App | What for | Download |
|---|---|---|
| **GitHub account** | Stores your project and publishes the website | [github.com/signup](https://github.com/signup) |
| **GitHub Desktop** | Brings the project to your computer and uploads changes | [desktop.github.com](https://desktop.github.com/) |
| **Node.js** ("LTS" version) | Creates the website preview | [nodejs.org](https://nodejs.org/) |
| **Obsidian** | Where you write all texts | [obsidian.md](https://obsidian.md/) |

For Node.js, download the **"LTS"** version and install it with all default settings. After that you never need to open Node.js again; it works in the background.

---

## 2. One-time setup

### 2.1 Create your own copy on GitHub

1. Open this template's page on GitHub (you'll get the link in the seminar).
2. Click the green **"Use this template"** button at the top right, then **"Create a new repository"**.
3. Enter a name, e.g. `portfolio`. Choose **Public** and click **"Create repository"**.

> **Tip:** If you name your repository `yourname.github.io` (with your GitHub username), the website will be available directly at `https://yourname.github.io`. Otherwise it lives at `https://yourname.github.io/portfolio/`.

### 2.2 Turn on publishing

1. In your new repository, click **Settings** at the top.
2. Click **Pages** on the left.
3. Under **Source**, choose **"GitHub Actions"**.

That's it. From now on, the website is published again automatically with every change.

### 2.3 Bring the project to your computer

1. Open **GitHub Desktop** and sign in with your GitHub account.
2. Choose **File → Clone repository …**, then your repository, and click **Clone**.
3. Remember the folder shown under **Local path**. That's where your project now lives.

### 2.4 Start the preview

Open the project folder (in GitHub Desktop: **Repository → Show in Finder / Show in Explorer**).

- **Mac:** double-click **`Start (Mac).command`**
- **Windows:** double-click **`Start (Windows).bat`**

The first time takes one to three minutes because building blocks are installed. Then your browser opens with your website at `http://localhost:5173`.

**Keep the black window open** while you work. Closing it ends the preview.

> **Mac – "cannot be opened because it is from an unidentified developer":**
> **Right-click** the file, choose **Open** and confirm with **Open**. This is only needed the first time.
>
> **Windows – "Windows protected your PC":**
> Click **More info**, then **Run anyway**.

### 2.5 Set up Obsidian

1. Open Obsidian and choose **"Open folder as vault"**.
2. In the project folder, choose the sub-folder **`inhalte`**. Important: exactly this folder, not the whole project folder.
3. If Obsidian asks whether you trust the vault, confirm with **"Trust"**.
4. Recommended: turn on **Settings → Core plugins → Templates**. Then you can create new works from a ready-made template (folder `_Vorlagen`).

Now change something in `Start.md` in Obsidian and save. The browser preview updates by itself.

---

## 3. Writing content

Everything that appears on the website lives in the `inhalte` folder. A detailed guide with all options is **right inside Obsidian in the note `README (English)`**.

```
inhalte/
├── Einstellungen.md        Settings: site name, navigation, languages
├── Gestaltung.md           Design: colours, fonts, structure (or set it in the browser)
├── Start.md                Text of the home page
├── CV.md                   CV
├── Werke/                  Works
│   └── My Work/
│       ├── My Work.md      Text and details of the work
│       └── media/          Images, audio, video, PDFs of the work
├── Seiten/                 Pages: contact, imprint, privacy …
└── _Vorlagen/              Templates (never appear on the website)
```

**The most important rules:**

- **Insert an image:** drag the image into the note in Obsidian. Caption: `![[photo.jpg|Installation view, photo: Name]]`
- **Several images directly below each other** (no empty line) become a **gallery**.
- **Video or music from YouTube, Vimeo, Bandcamp …:** put the link **on a line of its own**.
- **New section:** a heading `## …` or a horizontal rule `---` starts a new block that you can move separately in the layout.
- **Private notes:** everything between `%%` and `%%` does not appear on the website.
- **Don't publish yet:** write `publish: false` in a work's properties.
- **Folders and files starting with `_`** are never published.

---

## 4. Arranging the layout

Every page consists of **blocks**: title and details, text sections, images, galleries, videos, embeds. You decide how the blocks are arranged in the browser:

1. A black bar appears at the bottom of the preview. Click **"✎ Edit layout"**.
2. **Drag a block** → move it. **Drag an edge or corner** → wider, narrower, taller.
3. **Arrow keys** move the selected block; **Shift + arrow keys** change its size.
4. **"Insert row"** makes room above the selected block.
5. Click **"Save"**.

The layout is saved as a file next to the note (e.g. `My Work.layout.json`). This file only contains positions, no text. If you delete it, the website arranges the blocks automatically again.

**Good to know:**
- The grid has 12 columns. Blocks may overlap.
- New images or sections that don't have a place in the layout yet are appended at the bottom automatically.
- On **phones** all blocks are simply stacked, in the order of the note.
- The bar only exists in the preview. It's not there on the published website.
- **"Open in Obsidian"** jumps straight to the matching note.

---

## 5. Changing the look

**In the browser:** In the preview, click **"Aa Design"** at the bottom. A panel opens on the right. Every change is visible on the page instantly:

- **Presets:** seven ready-made styles (White Cube, Gallery, Editorial, Brutal, Night, Signal, Studio) as a starting point
- **Colours:** background, text, accent, lines, surfaces, plus an automatic dark mode
- **Type:** 18 free fonts, separately for text and titles, plus your own font files; body size, title size, weight, tracking, capitals, line height, link style
- **Structure:** header (row, centred, large name, sidebar), spacing, page width, rounded corners, gentle fade-in
- **Works overview:** free grid, large list with image preview on hover, or compact index; tile format and tile text

**"Save"** writes the values into `inhalte/Gestaltung.md`. You can change them there in Obsidian too. All options are listed in the note `README (English)` in the vault.

The fonts are served by your own website, not by Google, so no data goes to third parties. Only the two chosen fonts are published.

**Even more control:** The file `src/lib/styles/theme.css` contains the complete look as well-commented CSS. Open it with a text editor (e.g. [VS Code](https://code.visualstudio.com/)), change something and save. The preview shows the change instantly.

---

## 6. Publishing

1. Open **GitHub Desktop**. On the left you see all changed files.
2. At the bottom left under **Summary**, briefly write what you changed, e.g. "New work".
3. Click **"Commit to main"**.
4. Click **"Push origin"** at the top.

After one or two minutes the website is updated. You can follow the status on GitHub in the **Actions** tab:

| Symbol | Meaning |
|---|---|
| 🟡 yellow dot | being built |
| ✅ green tick | published |
| ❌ red cross | error. Click it, open **build** and read the red message. It names the file that has the problem. |

Your website's address is shown under **Settings → Pages**.

> **Own domain** (e.g. `www.yourname.com`): enter it under **Settings → Pages → Custom domain** and follow GitHub's instructions.

---

## 7. When something doesn't work

**The preview shows "Hoppla / Oops".**
The page names the file and the problem, e.g. a misspelled property. Fix the note in Obsidian and save. The page then reloads by itself.

**An image doesn't appear; there's a red box instead.**
The file was not found. Is it inside the `inhalte` folder? Is the name exactly right, including upper and lower case?

**"This image cannot be read".**
Probably a HEIC photo from an iPhone. Export it as JPG.

**The black window closes immediately or says "Node.js is missing".**
Install Node.js (LTS version) from [nodejs.org](https://nodejs.org/) and restart your computer.

**The preview starts but the browser doesn't open.**
Open [http://localhost:5173](http://localhost:5173) by hand.

**GitHub shows a red cross but the preview works.**
Usually a file wasn't uploaded. Check in GitHub Desktop whether files are still listed on the left, and publish them.

**GitHub says a file is too large.**
GitHub doesn't accept files over 100 MB. Upload long videos to Vimeo or YouTube and only insert the link.

**YouTube/Vimeo shows no preview image in the preview.**
Preview images are downloaded when publishing. Without an internet connection they're missing; the embed still works.

---

## 8. How it works

For everyone who wants to understand or change what happens under the hood: **[docs/how-it-works.md](docs/how-it-works.md)**.

In short: during the build, [SvelteKit](https://svelte.dev/docs/kit) reads the `inhalte` folder, turns every note into a list of blocks, applies the stored layout and writes finished HTML pages. The website needs no server and no database.

---

## 9. For instructors

- **Share as a template:** in your own repository, tick **"Template repository"** under **Settings → General**. Everyone then gets the "Use this template" button.
- **Requirements:** Node.js 22.17 or newer, SvelteKit 3, Svelte 5. Dependencies are deliberately few: unified/remark for Markdown, gray-matter, zod, sharp and the font packages from [Fontsource](https://fontsource.org/).
- **Example content:** the `inhalte` folder contains a fictional person "Alex Beispiel" with images, audio, video, PDF and embeds. The videos are example films by the Blender Foundation (CC BY). All other media were generated for the template and are free to use.
- **Exercise ideas:** create a new block type (`src/lib/components/blocks/`), add a new embed service (`src/lib/server/content/embeds.js`), create your own preset or a new design option in `src/lib/design.js` (the panel shows it automatically), your own effects in `theme.css`.
